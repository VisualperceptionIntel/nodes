#include "server_node.h"

void display(log_list* log_node,int type){
    while(log_node!=NULL){
        if(type==LOG_OK){
            cout<<BOLDGREEN<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;
        }else if(type==LOG_ERROR){
            cout<<BOLDRED<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;
            }
        log_node=log_node->next;
    }
}

void insertEnd(log_list* log_node){
    if(start == NULL){
        start = log_node;
        current = log_node;
        }else{
        current->next = log_node;
        current = log_node;
        }
}


void wizo_log(int display_log,string date_time, unsigned int type,string source, string log_line){
    string seperator= ",";
    ptr = new log_list;
    ptr->log_updated = date_time;
    ptr->log_type = type;
    ptr->log_parent_type = source;
    ptr->log_info =log_line;
    ptr->next = NULL;
    insertEnd(ptr);
    if(display_log==1)
        display(start,type);
}

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int create_tcp_socket(int portno)
{
    int sockfd; //Socket file descriptors and port number
    struct sockaddr_in serv_addr; ///two objects to store client and server address

    cout << "Hello there! This node is listening on port " << portno << " for incoming connections" << endl;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");
    int enable = 1;

    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
        error("ERROR setsockopt(SO_REUSEADDR) failed");

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        error("ERROR on binding");

    return sockfd;
}

