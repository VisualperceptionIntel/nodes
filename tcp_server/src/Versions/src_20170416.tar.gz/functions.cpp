#include "server_node.h"
////
////
////
void display(log_list* log_node,int type)
{
    while(log_node!=NULL)
    {
        if(type==LOG_OK)
        {
            cout<<BOLDGREEN<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;

        }
        else if(type==LOG_ERROR)
        {
            cout<<BOLDRED<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;

        }
        log_node=log_node->next;
    }
}
//
//
//void wizo_log(int display_log,string date_time, unsigned int type,string source, string log_line)
//{
//    string seperator= ",";
//    //log_string = date_time ;
//    // log_string=date_time+seperator + type+seperator+source+seperator+log_line;
//
//    ptr = new log_list;
//    ptr->log_updated = date_time;
//    ptr->log_type = type;
//    ptr->log_parent_type = source;
//    ptr->log_info =log_line;
//    ptr->next = NULL;
//    insertEnd(ptr);
//
//
//
//    // newptr = createNewNode(log_string);
//    if(display_log==1)
//        display(start,type);
//
//}
