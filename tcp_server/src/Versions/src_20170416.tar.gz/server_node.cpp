#include "server_node.h"
command_unit master_commands, mysql_commands, tcp_commands;
log_list *start, *newptr, *current, *ptr;
int done = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
char current_time[15];
char current_date_time[25];
boost::array<unsigned int,NUM_EMOTIONS> emotions_count;


int set_timer(struct timeval &tv, time_t sec)
{
    gettimeofday(&tv,NULL);
    tv.tv_sec+=sec;

    return 1;
}

int check_timer(struct timeval &tv, time_t sec)
{
    struct timeval ctv;
    gettimeofday(&ctv,NULL);

    if( (ctv.tv_sec >= tv.tv_sec) )
    {
        gettimeofday(&tv,NULL);
        tv.tv_sec+=sec;
        return 1;
    }
    else
        return 0;
}

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

void time_stamp(char* time_buffer)
{
    time_t rawtime;
    struct tm * timeinfo;
    //char time_buffer [40];
    time (&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(time_buffer,40,"%F %X",timeinfo);
    strftime(current_time,15,"%X",timeinfo);
}

void close_tcp_socket(int newsockfd, fd_set& masterfd)
{
    close(newsockfd);
    FD_CLR(newsockfd,&masterfd);
    printf("\nConnection on socket %i closed\n\n",newsockfd);
}

int create_tcp_socket(int portno)
{
    int sockfd; //Socket file descriptors and port number
    struct sockaddr_in serv_addr; ///two objects to store client and server address

    cout << "Hello there! This node is listening on port " << portno << " for incoming connections" << endl;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");
    int enable = 1;

    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
        error("ERROR setsockopt(SO_REUSEADDR) failed");

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        error("ERROR on binding");

    return sockfd;
}

int listen_for_client(int sockfd)
{
    int newsockfd; //Socket file descriptor
    socklen_t clilen; //object clilen of type socklen_t
    struct sockaddr_in cli_addr; ///object to store client address

    //listen(sockfd,10);
    clilen = sizeof(cli_addr);
    if(-1==(newsockfd = accept(sockfd, NULL,NULL)))
    {
        if (EWOULDBLOCK != errno)
        {
            error("ERROR on accept");
        }
    }
    return newsockfd;
}

char *tcp_read(int newsockfd)
{
    int n;
    char* read_buffer = new char[256];
    bzero(read_buffer,256);

    n = read(newsockfd,read_buffer,255);

    if (n < 0)
        error("ERROR reading from socket");
    if ( n==0 )
        return NULL;

    return read_buffer;
}

int tcp_write(int newsockfd, char msg[WRITE_BUFFER_LENGTH])
{
    int n;
    n = write(newsockfd, msg, strlen(msg));//WRITE_BUFFER_LENGTH);
    if (n > 0)
    {
        printf("\nMSG SENT: \n\"%s\"\n", msg);
        return 1;
    }
    if (n < 0)
    {
        printf("\nERROR writing to socket\n\n");
        return -1;
    }

    return 0;
}

int  tcp_str_to_array(char* rcv_data, str_tok_buffer str_tok_buf_tmp)
{
    char* pch;
    int j=1;
    /// str_tok_buf_tmp = {NULL};
    if( (rcv_data == NULL) || (sizeof(rcv_data) == 0) )
    {
        printf("\nWARNING: cannot split array, received msg empty.\n");
        return -1;
    }
    pch = strtok(rcv_data,",");
    str_tok_buf_tmp[0].tok = pch;
    while(pch != NULL)
    {
        pch = strtok(NULL,",");
        str_tok_buf_tmp[j].tok = pch;
        ++j;
    }
    if( strcmp(str_tok_buf_tmp[j-2].tok,"<EOC>") == 0)
    {
        for(int l=0; l<COMMAND_UNIT_LENGTH; ++l)
        {
            if( str_tok_buf_tmp[l].tok == NULL)
                break;
            else
                printf("Data at index [%i]: %s\n",l,str_tok_buf_tmp[l].tok);
        }
        return 1;
    }
    else
    {
        printf("\nWARNING: <EOC> not received, received: %s\n",str_tok_buf_tmp[j-2].tok);
        return -1;
    }
}

void update_master_commands(struct command_unit updated_values ,char is_updated[COMMAND_UNIT_LENGTH])
{
    char key[]="0123456789\\|<>;:,./?'@#~[]{}=+-_)(*&^%$£!¬`€'\"";
    char key2[]="\\|<>;/?'@#~[]{}=+_)(*&^%$£!¬`€'\"";
    if(master_commands.updated < updated_values.updated)
    {
        time_stamp(master_commands.updated);
        printf("\n\nUpdate Received @ %s\nFields Updated:\n",master_commands.updated);

        if( is_updated[IS_BASE_BUSY]==1 )
        {
            if( updated_values.is_base_busy == 0 || updated_values.is_base_busy==1 )
            {

                master_commands.is_base_busy = updated_values.is_base_busy;
                printf("is_base_busy value: %i\n",master_commands.is_base_busy);
                char buff[5];
                sprintf(buff,"%i",updated_values.is_base_busy);
                wizo_log(0,master_commands.updated,LOG_OK,"base",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_base_busy field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.is_base_busy);
            }
        }
        if( is_updated[BASE_POSITION_X]==1 )
        {
            if( updated_values.base_position_x>-2000.00 && updated_values.base_position_x<2000.00 )
            {
                master_commands.base_position_x = updated_values.base_position_x;
                printf("base_position_x value: %f\n",master_commands.base_position_x);
                char buff[10];
                sprintf(buff,"%f",updated_values.base_position_x);
                wizo_log(0,master_commands.updated,LOG_OK,"base",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_position_x field. Expected between -2000.00 and 2000.00. Received: %f\n\n",
                       updated_values.base_position_x);
            }
        }
        if( is_updated[BASE_POSITION_Y]==1 )
        {
            if( updated_values.base_position_y>-2000.00 && updated_values.base_position_y<2000.00 )
            {
                master_commands.base_position_y = updated_values.base_position_y;
                printf("base_position_y value: %f\n",master_commands.base_position_y);
                char buff[10];
                sprintf(buff,"%f",updated_values.base_position_y);
                wizo_log(0,master_commands.updated,LOG_OK,"base",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_position_y field. Expected between -2000.00 and 2000.00. Received: %f\n\n",
                       updated_values.base_position_y);
            }
        }
        if( is_updated[BASE_DESTINATION_X]==1 )
        {
            if( updated_values.base_destination_x>-2000.00 && updated_values.base_destination_x<2000.00 )
            {
                master_commands.base_destination_x = updated_values.base_destination_x;
                printf("base_destination_x value: %f\n",master_commands.base_destination_x);

                char buff[10];
                sprintf(buff,"%f",updated_values.base_destination_x);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval BASE_DESTINATION_X",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_destination_x field. Expected between -2000.00 and 2000.00. Received: %f\n\n",
                       updated_values.base_destination_x);
            }
        }
        if( is_updated[BASE_DESTINATION_Y]==1 )
        {
            if( updated_values.base_destination_y>-2000.00 && updated_values.base_destination_y<2000.00 )
            {
                master_commands.base_destination_y = updated_values.base_destination_y;
                printf("base_destination_y value: %f\n",master_commands.base_destination_y);

                char buff[10];
                sprintf(buff,"%f",updated_values.base_destination_y);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval BASE_DESTINATION_Y",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_destination_y field. Expected between -2000.00 and 2000.00. Received: %f\n\n",
                       updated_values.base_destination_y);
            }
        }
        if ( is_updated[BASE_FORWARD_STEP]==1 )
        {
            if( updated_values.base_forward_step<11 )
            {
                master_commands.base_forward_step = updated_values.base_forward_step;
                printf("base_forward_step value: %i\n",master_commands.base_forward_step);

                char buff[5];
                sprintf(buff,"%i",updated_values.base_forward_step);
                wizo_log(0,master_commands.updated,LOG_OK,"BASE_FORWARD_STEP",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_forward_step field. Expected between 0 and 10. Received: %i\n\n",
                       updated_values.base_forward_step);
            }
        }
        if( is_updated[BASE_BACKWARD_STEP]==1 )
        {
            if( updated_values.base_backward_step<11 )
            {
                master_commands.base_backward_step = updated_values.base_backward_step;
                printf("base_backward_step value: %i\n",master_commands.base_backward_step);

                char buff[5];
                sprintf(buff,"%i",updated_values.base_backward_step);
                wizo_log(0,master_commands.updated,LOG_OK,"BASE_BACKWARD_STEP",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_backward_step field. Expected between 0 and 10. Received: %i\n\n",
                       updated_values.base_backward_step);
            }
        }
        if( is_updated[BASE_ROTATE_LEFT]==1 )
        {
            if( updated_values.base_rotate_left<11 )
            {
                master_commands.base_rotate_left = updated_values.base_rotate_left;
                printf("base_rotate_left value: %i\n",master_commands.base_rotate_left);

                char buff[5];
                sprintf(buff,"%i",updated_values.base_rotate_left);
                wizo_log(0,master_commands.updated,LOG_OK,"BASE_ROTATE_LEFT",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_rotate_left field. Expected between 0 and 10. Received: %i\n\n",
                       updated_values.base_rotate_left);
            }
        }
        if( is_updated[BASE_ROTATE_RIGHT]==1 )
        {
            if( updated_values.base_rotate_right<11 )
            {
                master_commands.base_rotate_right = updated_values.base_rotate_right;
                printf("base_rotate_right value: %i\n",master_commands.base_rotate_right);

                char buff[5];
                sprintf(buff,"%i",updated_values.base_rotate_right);
                wizo_log(0,master_commands.updated,LOG_OK,"BASE_ROTATE_RIGHT",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_rotate_right field. Expected between 0 and 10. Received: %i\n\n",
                       updated_values.base_rotate_right);
            }
        }
        if( is_updated[IS_LEFT_ARM_BUSY]==1 )
        {
            if( updated_values.is_left_arm_busy >= 0 || updated_values.is_left_arm_busy <=100 )
            {
                master_commands.is_left_arm_busy = updated_values.is_left_arm_busy;
                printf("is_left_arm_busy value: %i\n",master_commands.is_left_arm_busy);

                char buff[5];
                sprintf(buff,"%i",updated_values.is_left_arm_busy);
                wizo_log(0,master_commands.updated,LOG_OK,"IS_LEFT_ARM_BUSY",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_left_arm_busy field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.is_left_arm_busy);
            }
        }
        if( is_updated[IS_RIGHT_ARM_BUSY]==1 )
        {
            if( updated_values.is_right_arm_busy >= 0 || updated_values.is_right_arm_busy <=100 )
            {
                master_commands.is_right_arm_busy = updated_values.is_right_arm_busy;
                printf("is_right_arm_busy value: %i\n",master_commands.is_right_arm_busy);

                char buff[5];
                sprintf(buff,"%i",updated_values.is_right_arm_busy);
                wizo_log(0,master_commands.updated,LOG_OK,"IS_RIGHT_ARM_BUSY",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_right_arm_busy field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.is_right_arm_busy);
            }
        }
        if( is_updated[LEFT_ARM_MOVE]==1 )
        {
            if( updated_values.left_arm_move >= 0 || updated_values.left_arm_move<=100 )
            {
                master_commands.left_arm_move = updated_values.left_arm_move;
                printf("left_arm_move value: %i\n",master_commands.left_arm_move);

                char buff[5];
                sprintf(buff,"%i",updated_values.left_arm_move);
                wizo_log(0,master_commands.updated,LOG_OK,"LEFT_ARM_MOVE",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for left_arm_move field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.left_arm_move);
            }
        }
        if( is_updated[RIGHT_ARM_MOVE]==1 )
        {
            if( updated_values.right_arm_move >= 0 || updated_values.right_arm_move<=100 )
            {
                master_commands.right_arm_move = updated_values.right_arm_move;
                printf("right_arm_move value: %i\n",master_commands.right_arm_move);

                char buff[5];
                sprintf(buff,"%i",updated_values.right_arm_move);
                wizo_log(0,master_commands.updated,LOG_OK,"RIGHT_ARM_MOVE",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for right_arm_move field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.right_arm_move);
            }
        }
        if( is_updated[EMOTION_STATUS]==1 )
        {
            if( updated_values.emotion_status<7 )
            {
                master_commands.emotion_status = updated_values.emotion_status;
                printf("emotion_status value: %i\n",master_commands.emotion_status);
                emotions_count[updated_values.emotion_status] +=1;

                char buff[5];
                sprintf(buff,"%i",updated_values.emotion_status);
                wizo_log(0,master_commands.updated,LOG_OK,"EMOTION_STATUS",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for emotion_status field. Expected between 0 and 6. Received: %i\n\n",
                       updated_values.emotion_status);
            }
        }
        if( is_updated[LIGHT_STATUS]==1 )
        {
            if( updated_values.light_status > 6 && updated_values.light_status < 10 )
            {
                master_commands.light_status = updated_values.light_status;
                printf("light_status value: %i\n",master_commands.light_status);

                char buff[5];
                sprintf(buff,"%i",updated_values.light_status);
                wizo_log(0,master_commands.updated,LOG_OK,"LIGHT_STATUS",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for light_status field. Expected between 7 and 9. Received: %i\n\n",
                       updated_values.light_status);
            }
        }
        if( is_updated[PRINT_STATUS]==1 )
        {
            if( updated_values.print_status == 0 || updated_values.print_status==1 )
            {
                master_commands.print_status = updated_values.print_status;
                printf("print_status value: %i\n",master_commands.print_status);

                char buff[5];
                sprintf(buff,"%i",updated_values.print_status);
                wizo_log(0,master_commands.updated,LOG_OK,"PRINT_STATUS",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for print_status field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.print_status);
            }
        }
        if( is_updated[FACE_COGNITION_STATUS]==1 )
        {
            if( updated_values.face_cognition_status == 0 || updated_values.face_cognition_status==1 )
            {
                master_commands.face_cognition_status = updated_values.face_cognition_status;
                printf("face_cognition_status value: %i\n",master_commands.face_cognition_status);

                char buff[5];
                sprintf(buff,"%i",updated_values.face_cognition_status);
                wizo_log(0,master_commands.updated,LOG_OK,"FACE_COGNITION_STATUS",buff);
            }
            else
            {
                cout << "value not valid" << endl;
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for face_cognition_status field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.face_cognition_status);
            }
        }
        if( is_updated[CARD_READER_STATUS]==1 )
        {
            if( updated_values.card_reader_status == 0 || updated_values.card_reader_status==1 )
            {
                master_commands.card_reader_status = updated_values.card_reader_status;
                printf("card_reader_status value: %i\n",master_commands.card_reader_status);

                char buff[5];
                sprintf(buff,"%i",updated_values.card_reader_status);
                wizo_log(0,master_commands.updated,LOG_OK,"CARD_READER_STATUS",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for card_reader_status field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.card_reader_status);
            }
        }
        if( is_updated[FACE_COGNITION_OUTCOME]==1 )
        {
            if( strpbrk(updated_values.face_cognition_outcome,key)==NULL )
            {
                if( master_commands.face_cognition_outcome != NULL)
                {
                    free(master_commands.face_cognition_outcome);
                    master_commands.face_cognition_outcome = new char[strlen(updated_values.face_cognition_outcome)+1];
                }
                else
                    master_commands.face_cognition_outcome = new char[strlen(updated_values.face_cognition_outcome)+1];
                strcpy(master_commands.face_cognition_outcome, updated_values.face_cognition_outcome);
                printf("face_cognition_outcome value: %s\n",master_commands.face_cognition_outcome);

                //char buff[5];
                //sprintf(buff,"%i",updated_values.card_reader_status);
                wizo_log(0,master_commands.updated,LOG_OK,"FACE_COGNITION_OUTCOME",updated_values.face_cognition_outcome);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in face_cognition_outcome field. Received: %s\nName can't contain %s.\n\n",
                       updated_values.face_cognition_outcome,key);
            }
        }
        if( is_updated[ID_CARD_NAME]==1 )
        {
            if( strpbrk(updated_values.id_card_name,key)==NULL )
            {
                if( master_commands.id_card_name != NULL)
                {
                    free(master_commands.id_card_name);
                    master_commands.id_card_name = new char[strlen(updated_values.id_card_name)+1];
                }
                else
                    master_commands.id_card_name = new char[strlen(updated_values.id_card_name)+1];
                strcpy(master_commands.id_card_name, updated_values.id_card_name);
                printf("id_card_name value: %s\n",master_commands.id_card_name);
                wizo_log(0,master_commands.updated,LOG_OK,"ID_CARD_NAME",updated_values.id_card_name);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in id_card_name field. Received: %s\nName can't contain %s.\n",
                       updated_values.id_card_name,key);
                wizo_log(1,master_commands.updated,LOG_ERROR,"ID_CARD_NAME",updated_values.id_card_name);
            }
        }
        if( is_updated[VISITEE_NAME]==1 )
        {
            if( strpbrk(updated_values.visitee_name,key)==NULL )
            {
                if( master_commands.visitee_name != NULL)
                {
                    free(master_commands.visitee_name);
                    master_commands.visitee_name = new char[strlen(updated_values.visitee_name)+1];
                }
                else
                    master_commands.visitee_name = new char[strlen(updated_values.visitee_name)+1];
                strcpy(master_commands.visitee_name, updated_values.visitee_name);
                printf("visitee_name value: %s\n",master_commands.visitee_name);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval VISITEE_NAME",updated_values.visitee_name);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in visitee_name field. Received: %s\nName can't contain %s.\n",
                       updated_values.visitee_name,key);
            }
        }
        if( is_updated[APPOINTMENT_DATE]==1 )
        {
            if( strpbrk(updated_values.appointment_date,key2)==NULL )
            {
                if( master_commands.appointment_date != NULL)
                {
                    free(master_commands.appointment_date);
                    master_commands.appointment_date = new char[strlen(updated_values.appointment_date)+1];
                }
                else
                    master_commands.appointment_date = new char[strlen(updated_values.appointment_date)+1];
                strcpy(master_commands.appointment_date, updated_values.appointment_date);
                printf("appointment_date value: %s\n",master_commands.appointment_date);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval APPOINTMENT_DATE",updated_values.appointment_date);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_date field. Received: %s\nName can't contain %s.\n",
                       updated_values.appointment_date,key2);
            }
        }
        if( is_updated[APPOINTMENT_TIME]==1 )
        {
            if( strpbrk(updated_values.appointment_time,key2)==NULL )
            {
                if( master_commands.appointment_time != NULL)
                {
                    free(master_commands.appointment_time);
                    master_commands.appointment_time = new char[strlen(updated_values.appointment_time)+1];
                }
                else
                    master_commands.appointment_time = new char[strlen(updated_values.appointment_time)+1];
                strcpy(master_commands.appointment_time, updated_values.appointment_time);
                printf("appointment_time value: %s\n",master_commands.appointment_time);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval APPOINTMENT_TIME",updated_values.appointment_time);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_time field. Received: %s\nName can't contain %s.\n",
                       updated_values.appointment_time,key2);
            }
        }
        if( is_updated[APPOINTMENT_LOCATION]==1 )
        {
            if( strpbrk(updated_values.appointment_location,key2)==NULL )
            {
                if( master_commands.appointment_location != NULL)
                {
                    free(master_commands.appointment_location);
                    master_commands.appointment_location = new char[strlen(updated_values.appointment_location)+1];
                }
                else
                    master_commands.appointment_location = new char[strlen(updated_values.appointment_location)+1];
                strcpy(master_commands.appointment_location, updated_values.appointment_location);
                printf("appointment_location value: %s\n",master_commands.appointment_location);
                wizo_log(0,master_commands.updated,LOG_OK,"MySQL retrieval APPOINTMENT_LOCATION",updated_values.appointment_location);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_location field. Received: %s\nName can't contain %s.\n",
                       updated_values.appointment_location,key2);
            }
        }
        if( is_updated[SPEECH_REQUEST]==1 )
        {
            if( updated_values.speech_request == 0 || updated_values.speech_request==1 )
            {
                master_commands.speech_request = updated_values.speech_request;
                printf("speech_request value: %i\n",master_commands.speech_request);

                char buff[5];
                sprintf(buff,"%i",updated_values.speech_request);
                wizo_log(0,master_commands.updated,LOG_OK,"SPEECH_REQUEST",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for speech_request field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.speech_request);
            }
        }
        if( is_updated[SPEECH_STATUS]==1 )
        {
            if( updated_values.speech_status == 0 || updated_values.speech_status==1 )
            {
                master_commands.speech_status = updated_values.speech_status;
                printf("speech_status value: %i\n",master_commands.speech_status);

                char buff[10];
                sprintf(buff,"%i",updated_values.speech_status);
                wizo_log(0,master_commands.updated,LOG_OK,"SPEECH_STATUS",buff);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for speech_status field. Expected between 0 and 1. Received: %i\n\n",
                       updated_values.speech_status);
            }
        }
        //********************************************************************
        if( is_updated[ARM_ACTIONS]==1 )
        {
            if( strpbrk(updated_values.arm_actions,key2)==NULL )
            {
                if( master_commands.arm_actions != NULL)
                {
                    free(master_commands.arm_actions);
                    master_commands.arm_actions = new char[strlen(updated_values.arm_actions)+1];
                }
                else
                    master_commands.arm_actions = new char[strlen(updated_values.arm_actions)+1];
                strcpy(master_commands.arm_actions, updated_values.arm_actions);
                printf("arm_actions value: %s\n",master_commands.arm_actions);


                wizo_log(0,master_commands.updated,LOG_OK,"ARM_ACTIONS",master_commands.arm_actions);

            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in arm_actions field. Received: %s\nName can't contain %s.\n",
                       updated_values.arm_actions,key2);
            }
        }


        if( is_updated[CURRENT_LATITUDE]==1 )
        {
            if( updated_values.current_latitude > -90 || updated_values.current_latitude < 90 )
            {
                master_commands.current_latitude = updated_values.current_latitude;
                printf("current_latitude value: %f\n",master_commands.current_latitude);

                char buff[10];
                sprintf(buff,"%f",updated_values.current_latitude);
                wizo_log(0,master_commands.updated,LOG_OK,"CURRENT_LATITUDE",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for current_latitude field. Expected between -90 and 90. Received: %f\n\n",
                       updated_values.current_latitude);
            }
        }

        if( is_updated[CURRENT_LONGITUDE]==1 )
        {
            if( updated_values.current_longitude > -180 || updated_values.current_longitude < 180 )
            {
                master_commands.current_longitude = updated_values.current_longitude;
                printf("current_longitude value: %f\n",master_commands.current_longitude);

                char buff[10];
                sprintf(buff,"%f",updated_values.current_longitude);
                wizo_log(0,master_commands.updated,LOG_OK,"CURRENT_LONGITUDE",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for current_longitude field. Expected between -180 and 180. Received: %f\n\n",
                       updated_values.current_longitude);
            }
        }

        if( is_updated[CURRENT_ALTITUDE]==1 )
        {
            if( updated_values.current_altitude >  -180 || updated_values.current_altitude < 180 )
            {
                master_commands.current_altitude = updated_values.current_altitude;
                printf("current_altitude value: %f\n",master_commands.current_altitude);

                char buff[10];
                sprintf(buff,"%f",updated_values.current_altitude);
                wizo_log(0,master_commands.updated,LOG_OK,"CURRENT_ALTITUDE",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for current_altitude field. Expected between -180 and 180. Received: %f\n\n",
                       updated_values.current_altitude);
            }
        }
        if( is_updated[OBJ_FRAME]==1 )
        {
            if( strpbrk(updated_values.obj_frame,key2)==NULL )
            {
                if( master_commands.obj_frame != NULL)
                {
                    free(master_commands.obj_frame);
                    master_commands.obj_frame = new char[strlen(updated_values.obj_frame)+1];
                }
                else
                    master_commands.obj_frame = new char[strlen(updated_values.obj_frame)+1];
                strcpy(master_commands.obj_frame, updated_values.obj_frame);
                printf("obj_frame value: %s\n",master_commands.obj_frame);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_FRAME",master_commands.obj_frame);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in obj_frame field. Received: %s\nName can't contain %s.\n",
                       updated_values.obj_frame,key2);
            }
        }
        if( is_updated[OBJ_X]==1 )
        {
            if( updated_values.obj_x >  -1000 || updated_values.obj_x < 1000 )
            {
                master_commands.obj_x = updated_values.obj_x;
                printf("obj_x value: %f\n",master_commands.obj_x);
                char buff[10];
                sprintf(buff,"%f",updated_values.obj_x);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_X",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for obj_x field. Expected between -1000 and 1000. Received: %f\n\n",
                       updated_values.obj_x);
            }
        }
        if( is_updated[OBJ_Y]==1 )
        {
            if( updated_values.obj_y >  -1000 || updated_values.obj_y < 1000 )
            {
                master_commands.obj_y = updated_values.obj_y;
                printf("obj_y value: %f\n",master_commands.obj_y);
                char buff[10];
                sprintf(buff,"%f",updated_values.obj_y);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_Y",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for obj_y field. Expected between -1000 and 1000. Received: %f\n\n",
                       updated_values.obj_y);
            }
        }
        if( is_updated[OBJ_Z]==1 )
        {
            if( updated_values.obj_z >  -1000 || updated_values.obj_z < 1000 )
            {
                master_commands.obj_z = updated_values.obj_z;
                printf("obj_z value: %f\n",master_commands.obj_z);
                char buff[10];
                sprintf(buff,"%f",updated_values.obj_z);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_Z",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for obj_z field. Expected between -1000 and 1000. Received: %f\n\n",
                       updated_values.obj_z);
            }
        }
        if( is_updated[OBJ_HEIGHT]==1 )
        {
            if( updated_values.obj_height >  0 || updated_values.current_altitude < 1 )
            {
                master_commands.obj_height = updated_values.obj_height;
                printf("obj_height value: %f\n",master_commands.obj_height);
                char buff[10];
                sprintf(buff,"%f",updated_values.obj_height);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_HEIGHT",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for obj_height field. Expected between 0 and 1. Received: %f\n\n",
                       updated_values.obj_height);
            }
        }
        if( is_updated[OBJ_WIDTH]==1 )
        {
            if( updated_values.obj_width >  0 || updated_values.obj_width < 1 )
            {
                master_commands.obj_width = updated_values.obj_width;
                printf("obj_width value: %f\n",master_commands.obj_width);
                char buff[10];
                sprintf(buff,"%f",updated_values.obj_width);
                wizo_log(0,master_commands.updated,LOG_OK,"OBJ_WIDTH",buff);
            }
            else
            {
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for obj_width field. Expected between 0 and 1. Received: %f\n\n",
                       updated_values.obj_width);
            }
        }


    }
    else
    {
        printf("\nWARNING: Requested update time stamped in the past. \nLast Master Update: %s, Time Stamp of Update: %s\n",
               master_commands.updated,updated_values.updated);
    }

    cout << "Update Completed\n" << endl;
    //exit(0);
}

int base_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"base_busy")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.is_base_busy=atoi(str_tok_buf_tmp[3].tok);
                is_updated[IS_BASE_BUSY] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"pos_x")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.base_position_x=atof(str_tok_buf_tmp[5].tok);
                is_updated[BASE_POSITION_X] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"pos_y")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 )
            {
                command_update.base_position_y=atof(str_tok_buf_tmp[7].tok);
                is_updated[BASE_POSITION_Y] = 1;
            }
        }
        /*if( strcmp(str_tok_buf_tmp[8].tok,"light_state")==0 ){
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 ){
                command_update.light_status=atoi(str_tok_buf_tmp[9].tok);
                is_updated[LIGHT_STATUS] = 1;
            }
        }*/
        if( strcmp(str_tok_buf_tmp[8].tok,"speech_request")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 )
            {
                command_update.speech_request=atoi(str_tok_buf_tmp[9].tok);
                is_updated[SPEECH_REQUEST] = 1;
            }
        }

        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int arms_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"left_busy")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.is_left_arm_busy=atoi(str_tok_buf_tmp[3].tok);
                is_updated[IS_LEFT_ARM_BUSY] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"right_busy")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.is_right_arm_busy=atoi(str_tok_buf_tmp[5].tok);
                is_updated[IS_RIGHT_ARM_BUSY] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"arm_actions")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 )
            {
                command_update.arm_actions=str_tok_buf_tmp[7].tok;

                if (strcmp(str_tok_buf_tmp[7].tok,"walk")==0)
                {
                    command_update.left_arm_move=WALK;
                    command_update.right_arm_move=WALK;
                }
                else if (strcmp(str_tok_buf_tmp[7].tok,"pick")==0)
                {
                    command_update.left_arm_move=PICK;
                    command_update.right_arm_move=PICK;
                }
                else if (strcmp(str_tok_buf_tmp[7].tok,"place")==0)
                {
                    command_update.left_arm_move=PLACE;
                    command_update.right_arm_move=PLACE;
                }
                else if (strcmp(str_tok_buf_tmp[7].tok,"wave")==0)
                {
                    command_update.left_arm_move=WAVE;
                    command_update.right_arm_move=WAVE;
                }
                else  //home
                {
                    command_update.left_arm_move=HOME;
                    command_update.right_arm_move=HOME;
                }


                is_updated[ARM_ACTIONS] = 1;
                is_updated[LEFT_ARM_MOVE] = 1;
                is_updated[RIGHT_ARM_MOVE] = 1;
            }
        }
        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int detect_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"emotion")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.emotion_status=atoi(str_tok_buf_tmp[3].tok);
                is_updated[EMOTION_STATUS] = 1;

            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"cog_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.face_cognition_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[FACE_COGNITION_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"cog_outcome")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 )
            {
                command_update.face_cognition_outcome=str_tok_buf_tmp[7].tok;
                is_updated[FACE_COGNITION_OUTCOME] = 1;

                str_tok_buffer sql_visit_tok_buf = {NULL};
                mysql_visit_update(sql_visit_tok_buf,is_updated,command_update ,2 );//1-scanner 2-cognition
            }
        }
        //###################################################
        //should be changed to face_detect_status
        //###################################################
        if( strcmp(str_tok_buf_tmp[8].tok,"speech_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 )
            {
                command_update.speech_status=atoi(str_tok_buf_tmp[9].tok);
                is_updated[SPEECH_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int printer_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"print_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.print_status=atoi(str_tok_buf_tmp[3].tok);
                is_updated[PRINT_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"card_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.card_reader_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[CARD_READER_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int face_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{

    int ret=1;
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"forward_step")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.base_forward_step=atoi(str_tok_buf_tmp[3].tok);
                is_updated[BASE_FORWARD_STEP] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"backward_step")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.base_backward_step=atoi(str_tok_buf_tmp[5].tok);
                is_updated[BASE_BACKWARD_STEP] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"rotate_left")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 )
            {
                command_update.base_rotate_left=atoi(str_tok_buf_tmp[7].tok);
                is_updated[BASE_ROTATE_LEFT] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[8].tok,"rotate_right")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 )
            {
                command_update.base_rotate_right=atoi(str_tok_buf_tmp[9].tok);
                is_updated[BASE_ROTATE_RIGHT] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[10].tok,"light_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[11].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[11].tok,"(null)")!=0 )
            {
                command_update.light_status=atoi(str_tok_buf_tmp[11].tok);
                is_updated[LIGHT_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[12].tok,"latitude")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[13].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[13].tok,"(null)")!=0 )
            {
                command_update.current_latitude=atof(str_tok_buf_tmp[13].tok);
                is_updated[CURRENT_LATITUDE] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[14].tok,"longitude")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[15].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[15].tok,"(null)")!=0 )
            {
                command_update.current_longitude=atof(str_tok_buf_tmp[15].tok);
                is_updated[CURRENT_LONGITUDE] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[16].tok,"altitude")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[17].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[17].tok,"(null)")!=0 )
            {
                command_update.current_altitude=atof(str_tok_buf_tmp[17].tok);
                is_updated[CURRENT_ALTITUDE] = 1;
            }
        }


        if( strcmp(str_tok_buf_tmp[18].tok,"welcome")==0 )
        {

            ret = 2;

        }


        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return ret;
}

int scanner_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"id_card_name")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.id_card_name=str_tok_buf_tmp[3].tok;

                //log_string=log_string+","+str_tok_buf_tmp[2].tok+":"+str_tok_buf_tmp[3].tok;

                is_updated[ID_CARD_NAME] = 1;

                str_tok_buffer sql_visit_tok_buf = {NULL};
                mysql_visit_update(sql_visit_tok_buf,is_updated,command_update,1 );//1-scanner 2-cognition
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"card_status")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.card_reader_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[CARD_READER_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}


int obj_detect_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
{
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        // Reset command structure
        command_update = command_unit();

        if( strcmp(str_tok_buf_tmp[2].tok,"frame")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 )
            {
                command_update.obj_frame=str_tok_buf_tmp[3].tok;
                is_updated[OBJ_FRAME] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"obj_x")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 )
            {
                command_update.obj_x=atof(str_tok_buf_tmp[5].tok);
                is_updated[OBJ_X] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"obj_y")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 )
            {
                command_update.obj_y=atof(str_tok_buf_tmp[7].tok);
                is_updated[OBJ_Y] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[8].tok,"obj_z")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 )
            {
                command_update.obj_z=atof(str_tok_buf_tmp[9].tok);
                is_updated[OBJ_Z] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[10].tok,"obj_height")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[11].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[11].tok,"(null)")!=0 )
            {
                command_update.obj_height=atof(str_tok_buf_tmp[11].tok);
                is_updated[OBJ_HEIGHT] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[12].tok,"obj_width")==0 )
        {
            if ( strcmp(str_tok_buf_tmp[13].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[13].tok,"(null)")!=0 )
            {
                command_update.obj_width=atof(str_tok_buf_tmp[13].tok);
                is_updated[OBJ_WIDTH] = 1;
            }
        }
        time_stamp(command_update.updated);
    }
    else
    {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}


//int welcome_msg_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp)
//{
//
//}

int lights_cmd_update(str_tok_buffer& str_tok_buf_tmp)
{
    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 )
    {
        return 1;
    }
    return -1;
}

//void print_command_struct(struct command_unit print_data, const char* str)
//{
//    printf("\n\n%s Conatins: \ncontrolid [%i], \nis_base_busy [%i], \nbase_position_x [%f], \nbase_position_y [%f],"
//           "\nbase_destination_x [%f], \nbase_destination_y [%f], \nbase_forward_step [%i], \nbase_backward_step [%i], \nbase_rotate_left [%i],"
//           "\nbase_rotate_right [%i], \nis_left_arm_busy [%i], \nis_right_arm_busy [%i], \nleft_arm_move [%i], \nright_arm_move [%i], \nemotion_status [%i],"
//           "\nlight_status [%i], \nprint_status [%i], \nface_cognition_status [%i], \ncard_reader_status [%i], \ncreated [%s], \nupdated [%s],"
//           "\nface_cognition_outcome [%s], \nid_card_name [%s], \nvisitee_name [%s], \nappointment_date [%s], \nappointment_time [%s], \nappointment_location [%s]\n",
//           str,print_data.controlid,print_data.is_base_busy,print_data.base_position_x,print_data.base_position_y,print_data.base_destination_x,
//           print_data.base_destination_y,print_data.base_forward_step,print_data.base_backward_step,print_data.base_rotate_left,print_data.base_rotate_right,
//           print_data.is_left_arm_busy,print_data.is_right_arm_busy,print_data.left_arm_move,print_data.right_arm_move,print_data.emotion_status,
//           print_data.light_status,print_data.print_status,print_data.face_cognition_status,print_data.card_reader_status,print_data.created,print_data.updated,
//           print_data.face_cognition_outcome,print_data.id_card_name,print_data.visitee_name,print_data.appointment_date,print_data.appointment_time,print_data.appointment_location);
//}

int send_master_commands_update(int newsockfd)
{
    char update_buffer[WRITE_BUFFER_LENGTH];

    //time_stamp(master_commands.updated);

    sprintf(update_buffer,"base_busy,%i,base_pos_x,%f,base_pos_y,%f,base_dest_x,%f,base_dest_y,%f,forward_step,%i,backward_step,%i,rotate_left,%i,rotate_right,%i,left_busy,%i,right_busy,%i,"
            "left_arm_move,%i,right_arm_move,%i,arm_action,%s,emotion_status,%i,light_status,%i,print_status,%i,face_cognition_status,%i,card_reader_status,%i,face_cognition_outcome,%s,id_card_name,%s,"
            "visitee_name,%s,appointment_date,%s,appointment_time,%s,appointment_location,%s,speech_request,%i,speech_status,%i,latitude,%f,longitude,%f,altitude,%f,frame,%s,obj_x,%f,obj_y,%f,obj_z,%f,obj_height,%f,obj_width,%f,<EOC>",
            master_commands.is_base_busy,master_commands.base_position_x,master_commands.base_position_y,master_commands.base_destination_x,master_commands.base_destination_y,master_commands.base_forward_step,
            master_commands.base_backward_step,master_commands.base_rotate_left,master_commands.base_rotate_right,master_commands.is_left_arm_busy,master_commands.is_right_arm_busy,master_commands.left_arm_move,
            master_commands.right_arm_move,master_commands.arm_actions,master_commands.emotion_status,master_commands.light_status,master_commands.print_status,master_commands.face_cognition_status,master_commands.card_reader_status,
            master_commands.face_cognition_outcome,master_commands.id_card_name,master_commands.visitee_name,master_commands.appointment_date,master_commands.appointment_time,master_commands.appointment_location,
            master_commands.speech_request,master_commands.speech_status,master_commands.current_latitude,master_commands.current_longitude,master_commands.current_altitude,master_commands.obj_frame,master_commands.obj_x,master_commands.obj_y,master_commands.obj_z,master_commands.obj_height,master_commands.obj_width);

    return tcp_write(newsockfd,update_buffer);
}


int send_welcome_msg(int newsockfd)
{
    char msg_buffer[WELCOME_BUFFER_LENGTH];

    //time_stamp(master_commands.updated);
    sprintf(msg_buffer,"base_busy,%i,base_pos_x,%f,base_pos_y,%f,base_dest_x,%f,base_dest_y,%f,forward_step,%i,backward_step,%i,rotate_left,%i,rotate_right,%i,left_busy,%i,right_busy,%i,"
            "left_arm_move,%i,right_arm_move,%i,arm_action,%s,emotion_status,%i,light_status,%i,print_status,%i,face_cognition_status,%i,card_reader_status,%i,face_cognition_outcome,%s,id_card_name,%s,"
            "visitee_name,%s,appointment_date,%s,appointment_time,%s,appointment_location,%s,speech_request,%i,speech_status,%i,latitude,%f,longitude,%f,altitude,%f,frame,%s,obj_x,%f,obj_y,%f,obj_z,%f,obj_height,%f,obj_width,%f,"
            "welcome_msg,Welcome your Highness Sheik Mansour bin Muhammad bin Rashid, we are honoured by your attendance to the UAE Drones for good award. We hope you enjoy!,<EOC>",
            master_commands.is_base_busy,master_commands.base_position_x,master_commands.base_position_y,master_commands.base_destination_x,master_commands.base_destination_y,master_commands.base_forward_step,
            master_commands.base_backward_step,master_commands.base_rotate_left,master_commands.base_rotate_right,master_commands.is_left_arm_busy,master_commands.is_right_arm_busy,master_commands.left_arm_move,
            master_commands.right_arm_move,master_commands.arm_actions,master_commands.emotion_status,master_commands.light_status,master_commands.print_status,master_commands.face_cognition_status,master_commands.card_reader_status,
            master_commands.face_cognition_outcome,master_commands.id_card_name,master_commands.visitee_name,master_commands.appointment_date,master_commands.appointment_time,master_commands.appointment_location,
            master_commands.speech_request,master_commands.speech_status,master_commands.current_latitude,master_commands.current_longitude,master_commands.current_altitude,master_commands.obj_frame,master_commands.obj_x,master_commands.obj_y,master_commands.obj_z,master_commands.obj_height,master_commands.obj_width);


    return tcp_write(newsockfd,msg_buffer);




}


void update_mysql_cmd_unit(str_tok_buffer str_tok_buf_tmp, string query_type,char is_updated[COMMAND_UNIT_LENGTH],struct command_unit& mysql_commands)
{

    if (query_type=="visit")
    {
        if( (str_tok_buf_tmp[DB_HOST].tok!="(NULL)") || (str_tok_buf_tmp[DB_HOST].tok!="(null)") )
        {
            mysql_commands.visitee_name = new char[strlen(str_tok_buf_tmp[DB_HOST].tok)+1];
            strcpy(mysql_commands.visitee_name,str_tok_buf_tmp[DB_HOST].tok);
            is_updated[VISITEE_NAME] = 1;
        }
        if( (str_tok_buf_tmp[DB_APPOINTMENT_DATETIME].tok!="(NULL)") || (str_tok_buf_tmp[DB_APPOINTMENT_DATETIME].tok!="(null)") )
        {
            char* pch;
            pch = strtok(str_tok_buf_tmp[DB_APPOINTMENT_DATETIME].tok," ");
            mysql_commands.appointment_date = new char[strlen(pch)+1];
            strcpy(mysql_commands.appointment_date,pch);
            pch = strtok(NULL," ");
            mysql_commands.appointment_time = new char[strlen(pch)+1];
            strcpy(mysql_commands.appointment_time,pch);
            is_updated[APPOINTMENT_DATE] = 1;
            is_updated[APPOINTMENT_TIME] = 1;
        }
        if( (str_tok_buf_tmp[DB_APPOINTMENT_LOCATION].tok!="(NULL)") || (str_tok_buf_tmp[DB_APPOINTMENT_LOCATION].tok!="(null)") )
        {
            mysql_commands.appointment_location = new char[strlen(str_tok_buf_tmp[2].tok)+1];
            strcpy(mysql_commands.appointment_location,str_tok_buf_tmp[2].tok);
//            mysql_commands.appointment_location = str_tok_buf_tmp[2].tok;
//            cout<<"--------"<<mysql_commands.appointment_location;
            is_updated[APPOINTMENT_LOCATION] = 1;
        }






    }
    else
    {


        if( (str_tok_buf_tmp[BASE_DESTINATION_X].tok!="(NULL)") || (str_tok_buf_tmp[BASE_DESTINATION_X].tok!="(null)") )
        {
            mysql_commands.base_destination_x = atof(str_tok_buf_tmp[BASE_DESTINATION_X].tok);
            is_updated[BASE_DESTINATION_X] = 1;
        }

        if( (str_tok_buf_tmp[BASE_DESTINATION_Y].tok!="(NULL)") || (str_tok_buf_tmp[BASE_DESTINATION_Y].tok!="(null)") )
        {
            mysql_commands.base_destination_y = atof(str_tok_buf_tmp[BASE_DESTINATION_Y].tok);
            is_updated[BASE_DESTINATION_Y] = 1;
        }

        if( (str_tok_buf_tmp[UPDATED].tok!="(NULL)") || (str_tok_buf_tmp[UPDATED].tok!="(null)") )
        {
            strcpy(mysql_commands.updated, str_tok_buf_tmp[UPDATED].tok);
            is_updated[UPDATED] = 1;
        }

        update_master_commands(mysql_commands, is_updated);

    }


}

int mysql_str_to_array(char* sql_data, str_tok_buffer str_tok_buf_tmp, string query_type,char is_updated[COMMAND_UNIT_LENGTH],struct command_unit& command_update)
{
    char* pch;
    int j=1;

    if( sql_data == NULL )
    {
        printf("\nWARNING: cannot split array, sql_data empty.\n");
        return -1;
    }

    pch = strtok(sql_data,",");

    str_tok_buf_tmp[0].tok = pch;

    while(pch != NULL)
    {
        pch = strtok(NULL,",");
        str_tok_buf_tmp[j].tok = pch;
        ++j;
    }

    for(int l=0; l<j; ++l)
    {
        if( str_tok_buf_tmp[l].tok == NULL )
            break;
        else
            printf("str_tok_buf_tmp[%i]: %s\n",l,str_tok_buf_tmp[l].tok);
    }

    update_mysql_cmd_unit(str_tok_buf_tmp, query_type,is_updated,command_update);
}


//read the fields from the database and return as a string.
string read_from_mysql_db(string query_type, char* name)
{
    MYSQL *connection;
    MYSQL_RES *result;
    MYSQL_ROW row;
    MYSQL_FIELD *field;
    std::string s;

    connection = mysql_init(NULL);

    if (mysql_real_connect(connection, "107.180.100.50", "wizoApp", "321Wizo..","Wizo", 0, NULL, 0) == NULL)
    {
        fprintf(stderr, "%s\n", mysql_error(connection));
        mysql_close(connection);
        //exit(1);
        return "";
    }

    if(query_type=="visit")
    {
        //and user_visit.start_datetime >= now() and user_visit.start_datetime < curdate()+1

        printf("%s\n",name);
        char* query = new char[512];
        sprintf(query,"SELECT first_name, start_datetime,pickup_locationid FROM Wizo.user_visit, Wizo.user_data WHERE user_visit.visitor_name = '%s' and user_data.userid = user_visit.host_userid and user_visit.start_datetime >= now() and user_visit.start_datetime < curdate()+1 ORDER BY user_visit.start_datetime desc",name);


        if(mysql_query(connection,query ))
        {
            ROS_INFO("Query Error: %s", mysql_error(connection));
            //exit(1);
        }
    }
    else
    {
        if(mysql_query(connection, "SELECT * FROM Wizo.control_unit ORDER BY control_unit.controlid desc limit 1"))
        {
            ROS_INFO("Query Error: %s", mysql_error(connection));
            //exit(1);
        }
    }
    result = mysql_use_result(connection);

    for(int i=0; i < mysql_field_count(connection); ++i)
    {
        std::stringstream ss;
        row = mysql_fetch_row(result);

        if(row <= 0)
        {
            printf("No row returned, table not updated.\n");
            return "";
        }

        for(int j=0; j < mysql_num_fields(result); ++j)
        {
            ss << row[j];
            if( j == mysql_num_fields(result)-1 ) s = s + row[j];
            else s = s + row[j] + ",";
        }
        //cout << "Row[] contains: " << s << endl;
        mysql_free_result(result);
        mysql_close(connection);

        return s;
    }
}

void update_mysql_db(char query_str[256])
{
    MYSQL *connection;
    MYSQL_RES *result;
    MYSQL_ROW row;
    MYSQL_FIELD *field;

    connection = mysql_init(NULL);

    if (mysql_real_connect(connection, "107.180.100.50", "wizoApp", "321Wizo..","Wizo", 0, NULL, 0) == NULL)
    {
        fprintf(stderr, "%s\n", mysql_error(connection));
        mysql_close(connection);
        //return -1;
    }

//    char query_str[256];
//    sprintf(query_str, "UPDATE Wizo.control_unit SET"
//            " control_unit.is_base_busy=%i,"
//            " control_unit.base_position_x=%f,"
//            " control_unit.base_position_y=%f,"
//            " control_unit.base_forward_step=%i,"
//            " control_unit.base_backward_step=%i,"
//            " control_unit.base_rotate_left=%i,"
//            " control_unit.base_rotate_right=%i,"
//            " control_unit.is_left_arm_busy=%i,"
//            " control_unit.is_right_arm_busy=%i,"
//            " control_unit.left_arm_move=%i,"
//            " control_unit.right_arm_move=%i,"
//            " control_unit.emotion_status=%i,"
//            " control_unit.light_status=%i,"
//            " control_unit.print_status=%i,"
//            " control_unit.face_cognition_status=%i,"
//            " control_unit.face_cognition_outcome=%s,"
//            " control_unit.card_reader_status=%i,"
//            " control_unit.updated=%s,"
//            " WHERE control_unit.controlid=1",master_commands.is_base_busy,master_commands.base_position_x,
//            master_commands.base_position_y,master_commands.base_forward_step,master_commands.base_backward_step,
//            master_commands.base_rotate_left,master_commands.base_rotate_right,master_commands.is_left_arm_busy,
//            master_commands.is_right_arm_busy,master_commands.left_arm_move,master_commands.right_arm_move,
//            master_commands.emotion_status,master_commands.light_status,master_commands.print_status,
//            master_commands.face_cognition_status,master_commands.face_cognition_outcome,master_commands.card_reader_status,
//            master_commands.updated);

    //printf("SQL Query formed:\n%s\n",query_str);

    if(mysql_query(connection, query_str))
    {
        fprintf(stderr,"Query Error: %s\n", mysql_error(connection));
        return;
    }
    mysql_close(connection);
}


//update Mysql database once any client request update--- or update on a set interval.. store values until then.
void mysql_cmd_update(str_tok_buffer& str_tok_buf_tmp)
{
    mysql_commands = command_unit();
    char is_updated[COMMAND_UNIT_LENGTH];
    char* name =new char[1];
    name[1]= '\0';


    string query= "all";
    string str = read_from_mysql_db(query,name);
    if( str.empty() )
        return;
    char* data_buffer = new char[str.size()+1];
    std::copy(str.begin(), str.end(), data_buffer);
    data_buffer[str.size()] = '\0';

    mysql_str_to_array(data_buffer, str_tok_buf_tmp,query,is_updated,mysql_commands);

    delete(data_buffer);
    str.clear();

    //print_command_struct(mysql_commands, "MYSQL_CMDS");
    //print_command_struct(master_commands,"MASTER_CMDS_2");
}

void mysql_visit_update(str_tok_buffer& str_tok_buf_tmp, char is_updated[COMMAND_UNIT_LENGTH],struct command_unit& command_update, int source) //source: 1-scanner 2-cognition
{
    string query= "visit";
    string str="";
    //printf("%s\n",command_update.id_card_name);
    if(source == 1)
        str = read_from_mysql_db(query,command_update.id_card_name);
    else if(source == 2)
        str = read_from_mysql_db(query,command_update.face_cognition_outcome);




    if( str.empty() || str=="" )
    {
        command_update.visitee_name= new char;
        command_update.visitee_name[1]='\0';
        command_update.appointment_date= new char;
        command_update.appointment_date[1]='\0';
        command_update.appointment_time= new char;
        command_update.appointment_time[1]='\0';
        command_update.appointment_location= new char;
        command_update.appointment_location[1]='\0';
        is_updated[VISITEE_NAME] = 1;
        is_updated[APPOINTMENT_DATE] = 1;
        is_updated[APPOINTMENT_TIME] = 1;
        is_updated[APPOINTMENT_LOCATION] = 1;
        return;
    }
    char* data_buffer = new char[str.size()+1];
    std::copy(str.begin(), str.end(), data_buffer);
    data_buffer[str.size()] = '\0';

    mysql_str_to_array(data_buffer, str_tok_buf_tmp,query,is_updated,command_update);

    delete(data_buffer);
    str.clear();

    //print_command_struct(mysql_commands, "MYSQL_CMDS");
    //print_command_struct(master_commands,"MASTER_CMDS_2");
}


void *thread_timer_function(void *arg)
{
    while(1)
    {
        time_t rawtime;
        struct tm * timeinfo;
        //char time_buffer [40];
        time (&rawtime);
        timeinfo = localtime(&rawtime);
        const char* reset_time= "18:00:00";
        strftime(current_time,15,"%X",timeinfo);
        if(strcmp(current_time,reset_time)==0)
        {
            for(int i=0; i<NUM_EMOTIONS; i++)
            {
                emotions_count[i]=0;
            }
            printf("emotion value reseted\n");
        }

        printf("                                                    \033[1;31mTime: %s \033[0m\n\033[1A",current_time);
        sleep(1);
    }


}

void *thread_mysql_function(void *arg)
{
    str_tok_buffer sql_str_tok_buf = {NULL};
    while(1)
    {
        printf("\033[1;31mMysql retrieval will be here\033[0m\n");
        mysql_cmd_update(sql_str_tok_buf);
        sleep(60);
    }


}

void *log_mysql_update_function(void *arg)
{
    log_list* log_node;
    log_list* temp_node;
    char query_str[256];
    int connection_status;

    while(1)
    {
        pthread_mutex_lock( &mutex );
        pthread_cond_wait( & cond, & mutex );
        pthread_mutex_unlock( &mutex );

        MYSQL *connection;
        MYSQL_RES *result;
        MYSQL_ROW row;
        MYSQL_FIELD *field;

        connection = mysql_init(NULL);

        if (mysql_real_connect(connection, "107.180.100.50", "wizoApp", "321Wizo..","Wizo", 0, NULL, 0) == NULL)
        {
            fprintf(stderr, "%s\n", mysql_error(connection));
            //mysql_close(connection);
            connection_status = -1;
            //return -1;
        }
        else
            connection_status = 1;


        log_node = start;
        printf("\033[1;31mLog updated to mysql here\033[0m\n");
        #pragma omp for
        for(;;)
        {
            if(log_node==NULL || connection_status == -1)
                break;
            else
            {
                cout<<BOLDGREEN<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;
                sprintf(query_str, "insert Wizo.transactions set transactions.info='%s',transactions.parent_type='%s', transactions.created='%s', transactions.updated='%s';",log_node->log_info.c_str(),log_node->log_parent_type.c_str(),log_node->log_updated.c_str(),log_node->log_updated.c_str());

                if(connection_status == 1)
                {
                    if(mysql_query(connection, query_str))
                    {
                        fprintf(stderr,"Query Error: %s\n", mysql_error(connection));
                        connection_status == -1;
                    }
                }
                temp_node=log_node->next;
                log_node=NULL;
                log_node=temp_node;
            }
        }



        mysql_close(connection);
        start=log_node;
        pthread_mutex_unlock( &mutex );
        sleep(10);

    }
}


void wizo_log(int display_log,string date_time, unsigned int type,string source, string log_line)
{
    string seperator= ",";
    //log_string = date_time ;
    // log_string=date_time+seperator + type+seperator+source+seperator+log_line;

    ptr = new log_list;
    ptr->log_updated = date_time;
    ptr->log_type = type;
    ptr->log_parent_type = source;
    ptr->log_info =log_line;
    ptr->next = NULL;
    insertEnd(ptr);



    // newptr = createNewNode(log_string);
    if(display_log==1)
        display(start,type);

}




void insertEnd(log_list* log_node)
{
    if(start == NULL)
    {
        start = log_node;
        current = log_node;
    }
    else
    {
        current->next = log_node;
        current = log_node;
    }
}

//void display(log_list* log_node,int type)
//{
//    while(log_node!=NULL)
//    {
//        if(type==LOG_OK)
//        {
//            cout<<BOLDGREEN<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;
//
//        }
//        else if(type==LOG_ERROR)
//        {
//            cout<<BOLDRED<<log_node->log_updated<<","<<log_node->log_parent_type<<","<<log_node->log_info<<"->"<<RESET<<endl;
//
//        }
//        log_node=log_node->next;
//    }
//}

void *exit_thread_function(void *arg)
{
    char text[100];
    char custom;
    while(1)
    {
        scanf("%s",text);
        if (text[0] == 'q'&& text[1]=='q')
            exit(1);

    }
}

//void* ThreadEntry( void* id )
//{
// // const int myid = (long)id; // force the pointer to be a 64bit integer
//while(1){
//  const int workloops = 5;
//
//  pthread_mutex_lock( &mutex );
//
//  pthread_cond_wait( & cond, & mutex );
//
//  for( int i=0; i<workloops; i++ )
//    {
//      printf( "[thread d] working (%d/%d)\n", i, workloops );
//     // sleep(1); // simulate doing some costly work
//    }
//
//  // we're going to manipulate done and use the cond, so we need the mutex
//
//
//  // increase the count of threads that have finished their work.
//  done++;
//  printf( "[thread d] done is now %d. Signalling cond.\n", done );
//
//  // wait up the main thread (if it is sleeping) to test the value of done
//
//  pthread_mutex_unlock( & mutex );
//}
//  return NULL;
//}


int main (int argc, char** argv)
{
    char log_buff[10];
    start = NULL;
    pthread_t timer_thread, mysql_thread, log_mysl_update_thread,exit_thread,local_db_thread;
    int ret=pthread_create(&timer_thread,NULL,&thread_timer_function,NULL);
    int ret_msql=pthread_create(&mysql_thread,NULL,&thread_mysql_function,NULL);
    int ret_log =pthread_create(&log_mysl_update_thread,NULL,&log_mysql_update_function,NULL);
    int ret_exit = pthread_create(&exit_thread,NULL,&exit_thread_function,NULL);

//pthread_create( &threads, NULL, &ThreadEntry, NULL );


    ros::init(argc, argv, "server_node");
    ros::NodeHandle nh;



    int sockfd, newsockfd, maxfd, portno; //Socket file descriptors and port number
    char* read_buffer;//[256]; // buffer array of size 256
    char write_buffer[256]; // buffer array of size 256 for sending messages
    int n, update_success=0;

    str_tok_buffer str_tok_buf = {NULL};


    ros::Duration d(0.001); // 1000Hz

    if (argc < 2)
    {
        fprintf(stderr,"ERROR, no port provided\n");
        //sprintf(log_buff,"port nummber: %i",atoi(argv[1]));
        wizo_log(1,current_time,LOG_ERROR,"Server started","No port provided");

        exit(1);
    }

    sprintf(log_buff,"port nummber: %i",atoi(argv[1]));
    wizo_log(1,current_time,LOG_OK,"Server started",log_buff);

    //print_mysql_commands();

    portno = atoi(argv[1]);
    sockfd = create_tcp_socket(portno);
    listen(sockfd,10);
    newsockfd = listen_for_client(sockfd);

    if (-1 == (fcntl(sockfd, F_SETFD, O_NONBLOCK)))
    {
        printf("ERROR Failed to set nonblock flag\n");
        exit(1);
    }

    //cout<<"sockfd: "<<sockfd<<endl;
    //cout<<"newsockfd: "<<newsockfd<<endl;

    fd_set sockset, masterfd;
    FD_ZERO(&sockset);
    FD_ZERO(&masterfd);
    FD_SET(sockfd, &masterfd);
    FD_SET(newsockfd, &masterfd);

    maxfd = newsockfd;

    struct timeval tv, tv_timer; // timeout struct for socket calls

    set_timer(tv_timer,MYSQL_UPDATE_TIME);

    int temp_speech = 0;
    master_commands.speech_request = temp_speech;

    while(ros::ok())
    {
        pthread_mutex_lock( &mutex );
        //cout << "just looping" << endl;
        memcpy(&sockset,&masterfd,sizeof(masterfd));


        int fail_count = 0;

        while( update_success < 1 )
        {
            if( fail_count > 2 )
            {
                close_tcp_socket(newsockfd,masterfd);
                break;
            }

            tv.tv_sec = 2;
            printf("Waiting for message from client on socket %i\n",newsockfd);
            int result = select(newsockfd + 1, &sockset, NULL, NULL, &tv);

            printf("Number of SOCK Fd's with read event ready: %i\n",result);

            if (result < 0)
            {
                printf("\nWARNING: No Read Event on Any Socket\n");
            }
            else if (FD_ISSET(newsockfd, &sockset)) //if (result == 1) {
            {
                // The socket has data. For good measure, it's not a bad idea to test further
                printf("Read Event on Socket %i, I/O in progress...\n",newsockfd);

                read_buffer = new char[256];
                read_buffer = tcp_read(newsockfd);
                printf("\n\nMSG RECEIVED: \n\"%s\"\n\n",read_buffer);
                wizo_log(1,current_time,LOG_OK,"client msg received",read_buffer);

                // Split received msg and update cmd structures.
                if(tcp_str_to_array(read_buffer,str_tok_buf)>0)
                {

                    if(strcmp(str_tok_buf[0].tok,"base")==0)
                    {
                        update_success = base_cmd_update(tcp_commands, str_tok_buf);
                        if( update_success > 0 ) {}
//                            update_mysql_db(); // updates base_pos_x/y and is_busy at the moment
                    }
                    else if(strcmp(str_tok_buf[0].tok,"arms")==0)
                    {
                        update_success = arms_cmd_update(tcp_commands, str_tok_buf);
                    }
                    else if(strcmp(str_tok_buf[0].tok,"detect")==0)
                    {
                        update_success = detect_cmd_update(tcp_commands, str_tok_buf);
                    }
                    else if(strcmp(str_tok_buf[0].tok,"printer")==0)
                    {
                        update_success = printer_cmd_update(tcp_commands, str_tok_buf);
                    }
                    else if(strcmp(str_tok_buf[0].tok,"face")==0)
                    {
                        update_success = face_cmd_update(tcp_commands, str_tok_buf);
                        /*   char write_buffer[] = "FAIL";
                           tcp_write(newsockfd, write_buffer);
                           update_success = 0;*/
                    }
                    else if(strcmp(str_tok_buf[0].tok,"scanner")==0)
                    {
                        pthread_cond_signal( &cond );
//                        string seperator= ",";
//                        log_string = current_time ;
//                        log_string+=seperator + str_tok_buf[0].tok;
//
                        update_success = scanner_cmd_update(tcp_commands, str_tok_buf);
//
//                        newptr = createNewNode(log_string);

                        //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                    }
                    else if(strcmp(str_tok_buf[0].tok,"lights")==0)
                    {
                        update_success = lights_cmd_update(str_tok_buf);
                        //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                    }
                    else if(strcmp(str_tok_buf[0].tok,"object_detect")==0)
                    {
                        update_success =obj_detect_cmd_update(tcp_commands, str_tok_buf);;
                        //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                    }
                    else if(strcmp(str_tok_buf[0].tok,"welcome")==0)
                    {
                        update_success =2;
                        //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                    }
                    else if(strcmp(str_tok_buf[0].tok,"master_request")==0)
                    {
                        update_success = 1;
                        printf("Values Requested\n");
                        //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                    }
                    else
                    {
                        update_success = -1;
                    }
                    if( update_success < 0 )
                    {
                        char write_buffer[] = "WARN: MSG not recognised,<EOC>";
                        if ( tcp_write(newsockfd,write_buffer) < 0)
                        {
                            close_tcp_socket(newsockfd, masterfd);
                            break;
                        }
                        ++fail_count;
                        continue;
                    }

                    if( update_success>0 )
                    {

                        if (update_success == 2)
                        {
                            send_welcome_msg(newsockfd);
                        }
                        else
                        {
                            // Send Master Commands Update
                            send_master_commands_update(newsockfd);
                        }

                        std::cout <<"\nHighest emotion index is "<< std::distance(emotions_count.begin(), std::max_element(emotions_count.begin(), emotions_count.end()))<<endl;
                        // close socket and remove from FD set
                        close_tcp_socket(newsockfd,masterfd);

                        maxfd = sockfd;
                        free(read_buffer);
                        break;
                    }
                }
                else
                {
                    char write_buffer[] = "WARN: Message received not comma seperated";
                    if( tcp_write(newsockfd,write_buffer) < 0 )
                    {
                        close_tcp_socket(newsockfd, masterfd);
                        break;
                    }
                    ++fail_count;
                    continue;
                }
                free(read_buffer);
            }

            {
                char write_buffer[] = "FAIL";
                if ( tcp_write(newsockfd,write_buffer) < 0)
                {
                    close_tcp_socket(newsockfd, masterfd);
                    break;
                }
                ++fail_count;
            }
        }

        pthread_cond_signal( &cond );
        pthread_mutex_unlock( & mutex );
        printf("Waiting for connection..\n");
        newsockfd = listen_for_client(sockfd);
        FD_SET(newsockfd,&masterfd);
        printf("Connection accepted on socket %i\n",newsockfd);
        update_success = 0;

    }
    return 0;
}
