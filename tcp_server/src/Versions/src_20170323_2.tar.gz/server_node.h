#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sstream>
#include <time.h>
#include <sys/fcntl.h>
#include <mysql/mysql.h>
#include "std_msgs/String.h"
#include <algorithm>  //sort
#include <valarray>   //valarray
#include <pthread.h>
//#include "json.hpp"
// Index Mappings for Command Unit
#define IS_BASE_BUSY 1
#define BASE_POSITION_X 2
#define BASE_POSITION_Y 3
#define BASE_DESTINATION_X 4
#define BASE_DESTINATION_Y 5
#define BASE_FORWARD_STEP 6
#define BASE_BACKWARD_STEP 7
#define BASE_ROTATE_LEFT 8
#define BASE_ROTATE_RIGHT 9
#define IS_LEFT_ARM_BUSY 10
#define IS_RIGHT_ARM_BUSY 11
#define LEFT_ARM_MOVE 12
#define RIGHT_ARM_MOVE 13
#define EMOTION_STATUS 14
#define LIGHT_STATUS 15
#define PRINT_STATUS 16
#define FACE_COGNITION_STATUS 17
#define CARD_READER_STATUS 18
#define UPDATED 20
#define FACE_COGNITION_OUTCOME 21
#define ID_CARD_NAME 22
#define VISITEE_NAME 23
#define APPOINTMENT_DATE 24
#define APPOINTMENT_TIME 25
#define APPOINTMENT_LOCATION 26
#define SPEECH_REQUEST 27
#define SPEECH_STATUS  28
#define ARM_ACTIONS 29
#define CURRENT_LATITUDE 30
#define CURRENT_LONGITUDE 31
#define CURRENT_ALTITUDE 32
// Buffer sizes
#define COMMAND_UNIT_LENGTH 33
#define WRITE_BUFFER_LENGTH 1024
// Update frequency for mysql
#define MYSQL_UPDATE_TIME 150

#define NUM_EMOTIONS 7
