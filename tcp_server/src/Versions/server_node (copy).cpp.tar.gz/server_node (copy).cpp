#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <sstream>
#include <time.h>
#include <sys/fcntl.h>
#include <mysql/mysql.h>
#include "std_msgs/String.h"
// Index Mappings for Command Unit
#define IS_BASE_BUSY 1
#define BASE_POSITION_X 2
#define BASE_POSITION_Y 3
#define BASE_DESTINATION_X 4
#define BASE_DESTINATION_Y 5
#define BASE_FORWARD_STEP 6
#define BASE_BACKWARD_STEP 7
#define BASE_ROTATE_LEFT 8
#define BASE_ROTATE_RIGHT 9
#define IS_LEFT_ARM_BUSY 10
#define IS_RIGHT_ARM_BUSY 11
#define LEFT_ARM_MOVE 12
#define RIGHT_ARM_MOVE 13
#define EMOTION_STATUS 14
#define LIGHT_STATUS 15
#define PRINT_STATUS 16
#define FACE_COGNITION_STATUS 17
#define CARD_READER_STATUS 18
#define UPDATED 20
#define FACE_COGNITION_OUTCOME 21
#define ID_CARD_NAME 22
#define VISITEE_NAME 23
#define APPOINTMENT_DATE 24
#define APPOINTMENT_TIME 25
#define APPOINTMENT_LOCATION 26
#define SPEECH_REQUEST 27
// Buffer sizes
#define COMMAND_UNIT_LENGTH 28
#define WRITE_BUFFER_LENGTH 1024
// Update frequency for mysql
#define MYSQL_UPDATE_TIME 15

using namespace std;

// Command unit data structure
struct command_unit {            // Current Indexes:
    unsigned int controlid;              //  0 
    unsigned int is_base_busy;           //  1
    float base_position_x;               //  2
    float base_position_y;               //  3
    float base_destination_x;            //  4
    float base_destination_y;            //  5
    unsigned int  base_forward_step;     //  6
    unsigned int  base_backward_step;    //  7
    unsigned int  base_rotate_left;      //  8
    unsigned int  base_rotate_right;     //  9
    unsigned int  is_left_arm_busy;      // 10
    unsigned int  is_right_arm_busy;     // 11
    unsigned int  left_arm_move;         // 12
    unsigned int  right_arm_move;        // 13
    unsigned int  emotion_status;        // 14
    unsigned int  light_status;          // 15
    unsigned int  print_status;          // 16
    unsigned int  face_cognition_status; // 17
    unsigned int  card_reader_status;    // 18
    char  created[40];                   // 19
    char  updated[40];                   // 20
    char*  face_cognition_outcome;       // 21
    char*  id_card_name;                 // 22
    char*  visitee_name;                 // 23
    char*  appointment_date;             // 24
    char*  appointment_time;             // 25
    char*  appointment_location;         // 26
    unsigned int speech_request;         // 27
} master_commands, mysql_commands, tcp_commands; // 3 instances of object

// object to take string tokens when split from comma seperated string
struct string_token {
    char * tok;
}; 
// defines array of string_token objects
typedef string_token str_tok_buffer[COMMAND_UNIT_LENGTH];
// Function prototypes
void print_command_struct(struct command_unit print_data, const char* str);

int set_timer(struct timeval &tv, time_t sec){
    gettimeofday(&tv,NULL);
    tv.tv_sec+=sec;
 
    return 1;
}
 
int check_timer(struct timeval &tv, time_t sec){
    struct timeval ctv;
    gettimeofday(&ctv,NULL);
 
    if( (ctv.tv_sec >= tv.tv_sec) )
    {
        gettimeofday(&tv,NULL);
        tv.tv_sec+=sec;
        return 1;
    }
    else
        return 0;
}

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void time_stamp(char* time_buffer){
    time_t rawtime;
    struct tm * timeinfo;
    //char time_buffer [40];
    time (&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(time_buffer,40,"%F %X",timeinfo);
}

void close_tcp_socket(int newsockfd, fd_set& masterfd){
    close(newsockfd);
    FD_CLR(newsockfd,&masterfd);
    printf("\nConnection on socket %i closed\n\n",newsockfd);
}

int create_tcp_socket(int portno){
    int sockfd; //Socket file descriptors and port number
    struct sockaddr_in serv_addr; ///two objects to store client and server address

    cout << "Hello there! This node is listening on port " << portno << " for incoming connections" << endl;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");
    int enable = 1;

    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
        error("ERROR setsockopt(SO_REUSEADDR) failed");

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
            error("ERROR on binding");

    return sockfd;
}

int listen_for_client(int sockfd){
    int newsockfd; //Socket file descriptor
    socklen_t clilen; //object clilen of type socklen_t
    struct sockaddr_in cli_addr; ///object to store client address

    //listen(sockfd,10);
    clilen = sizeof(cli_addr);
    if(-1==(newsockfd = accept(sockfd, NULL,NULL))){ //(struct sockaddr *) &cli_addr, &clilen);
        if (EWOULDBLOCK != errno){
            error("ERROR on accept");
        }
    }
    //if (newsockfd < 0)
    //    error("ERROR on accept");
    return newsockfd;
}

char *tcp_read(int newsockfd){
    int n;
    char* read_buffer = new char[256];
    bzero(read_buffer,256);
    //bzero(write_buffer,256);

   // cout << "Read Incoming Msgs" << endl;
    n = read(newsockfd,read_buffer,255);
   // cout << "Read Complete" << endl;

    if (n < 0) 
        error("ERROR reading from socket");
    if ( n==0 )
        return NULL;//strcpy(read_buffer,"EMPTY");

    return read_buffer;
}

int tcp_write(int newsockfd, char msg[WRITE_BUFFER_LENGTH]){
    
    int n;
    n = write(newsockfd, msg, strlen(msg));//WRITE_BUFFER_LENGTH);
    if (n > 0) {
        printf("\nMSG SENT: \n\"%s\"\n", msg);
        return 1;
    }
    if (n < 0) {
        printf("\nERROR writing to socket\n\n");
        return -1;
    }
        
    return 0;
}

int  tcp_str_to_array(char* rcv_data, str_tok_buffer str_tok_buf_tmp){
    char* pch;
    int j=1;
   /// str_tok_buf_tmp = {NULL};
    if( (rcv_data == NULL) || (sizeof(rcv_data) == 0) ){
        printf("\nWARNING: cannot split array, received msg empty.\n");
        return -1;
    }
    pch = strtok(rcv_data,",");
    str_tok_buf_tmp[0].tok = pch;
    while(pch != NULL){
        pch = strtok(NULL,",");
        str_tok_buf_tmp[j].tok = pch;
        ++j;
    }
    if( strcmp(str_tok_buf_tmp[j-2].tok,"<EOC>") == 0){
        for(int l=0;l<COMMAND_UNIT_LENGTH;++l){
            if( str_tok_buf_tmp[l].tok == NULL)
                break;
            else
            printf("Data at index [%i]: %s\n",l,str_tok_buf_tmp[l].tok);
        }
        return 1;
    }
    else{
        printf("\nWARNING: <EOC> not received, received: %s\n",str_tok_buf_tmp[j-2].tok);
        return -1;
    }
}

void update_master_commands(struct command_unit updated_values ,char is_updated[COMMAND_UNIT_LENGTH]){
    char key[]="0123456789\\|<>;:,./?'@#~[]{}=+-_)(*&^%$£!¬`€'\"";
    char key2[]="\\|<>;/?'@#~[]{}=+-_)(*&^%$£!¬`€'\"";
    if(master_commands.updated < updated_values.updated){
        time_stamp(master_commands.updated);
        printf("\n\nUpdate Received @ %s\nFields Updated:\n",master_commands.updated);
        if( is_updated[IS_BASE_BUSY]==1 ){
            if( updated_values.is_base_busy == 0 || updated_values.is_base_busy==1 ){
                master_commands.is_base_busy = updated_values.is_base_busy;
                printf("is_base_busy value: %i\n",master_commands.is_base_busy);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_base_busy field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.is_base_busy);
            }
        }
        if( is_updated[BASE_POSITION_X]==1 ){
            if( updated_values.base_position_x>-2000.00 && updated_values.base_position_x<2000.00 ){
                master_commands.base_position_x = updated_values.base_position_x;
                printf("base_position_x value: %f\n",master_commands.base_position_x);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_position_x field. Expected between -2000.00 and 2000.00. Received: %f\n\n", 
                updated_values.base_position_x);
            }
        }
        if( is_updated[BASE_POSITION_Y]==1 ){
            if( updated_values.base_position_y>-2000.00 && updated_values.base_position_y<2000.00 ){
                master_commands.base_position_y = updated_values.base_position_y;
                printf("base_position_y value: %f\n",master_commands.base_position_y);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_position_y field. Expected between -2000.00 and 2000.00. Received: %f\n\n", 
                updated_values.base_position_y);
            }
        }
        if( is_updated[BASE_DESTINATION_X]==1 ){
            if( updated_values.base_destination_x>-2000.00 && updated_values.base_destination_x<2000.00 ){
                master_commands.base_destination_x = updated_values.base_destination_x;
                printf("base_destination_x value: %f\n",master_commands.base_destination_x);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_destination_x field. Expected between -2000.00 and 2000.00. Received: %f\n\n", 
                updated_values.base_destination_x);
            }
        }
        if( is_updated[BASE_DESTINATION_Y]==1 ){
            if( updated_values.base_destination_y>-2000.00 && updated_values.base_destination_y<2000.00 ){
                master_commands.base_destination_y = updated_values.base_destination_y;
                printf("base_destination_y value: %f\n",master_commands.base_destination_y);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_destination_y field. Expected between -2000.00 and 2000.00. Received: %f\n\n", 
                updated_values.base_destination_y);
            }
        }
        if ( is_updated[BASE_FORWARD_STEP]==1 ){
            if( updated_values.base_forward_step<11 ){
                master_commands.base_forward_step = updated_values.base_forward_step;   
                printf("base_forward_step value: %i\n",master_commands.base_forward_step);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_forward_step field. Expected between 0 and 10. Received: %i\n\n", 
                updated_values.base_forward_step);
            }
        }
        if( is_updated[BASE_BACKWARD_STEP]==1 ){
            if( updated_values.base_backward_step<11 ){
                master_commands.base_backward_step = updated_values.base_backward_step;   
                printf("base_backward_step value: %i\n",master_commands.base_backward_step);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_backward_step field. Expected between 0 and 10. Received: %i\n\n", 
                updated_values.base_backward_step);
            }
        }
        if( is_updated[BASE_ROTATE_LEFT]==1 ){
            if( updated_values.base_rotate_left<11 ){
                master_commands.base_rotate_left = updated_values.base_rotate_left;   
                printf("base_rotate_left value: %i\n",master_commands.base_rotate_left);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_rotate_left field. Expected between 0 and 10. Received: %i\n\n", 
                updated_values.base_rotate_left);
            }
        }
        if( is_updated[BASE_ROTATE_RIGHT]==1 ){
            if( updated_values.base_rotate_right<11 ){
                master_commands.base_rotate_right = updated_values.base_rotate_right;   
                printf("base_rotate_right value: %i\n",master_commands.base_rotate_right);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for base_rotate_right field. Expected between 0 and 10. Received: %i\n\n", 
                updated_values.base_rotate_right);
            }
        }
        if( is_updated[IS_LEFT_ARM_BUSY]==1 ){
            if( updated_values.is_left_arm_busy == 0 || updated_values.is_left_arm_busy==1 ){
                master_commands.is_left_arm_busy = updated_values.is_left_arm_busy;
                printf("is_left_arm_busy value: %i\n",master_commands.is_left_arm_busy);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_left_arm_busy field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.is_left_arm_busy);
            }
        }
        if( is_updated[IS_RIGHT_ARM_BUSY]==1 ){
            if( updated_values.is_right_arm_busy == 0 || updated_values.is_right_arm_busy==1 ){
                master_commands.is_right_arm_busy = updated_values.is_right_arm_busy;
                printf("is_right_arm_busy value: %i\n",master_commands.is_right_arm_busy);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for is_right_arm_busy field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.is_right_arm_busy);
            }
        }
        if( is_updated[LEFT_ARM_MOVE]==1 ){
            if( updated_values.left_arm_move == 0 || updated_values.left_arm_move==1 ){
                master_commands.left_arm_move = updated_values.left_arm_move;
                printf("left_arm_move value: %i\n",master_commands.left_arm_move);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for left_arm_move field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.left_arm_move);
            }
        }
        if( is_updated[RIGHT_ARM_MOVE]==1 ){
            if( updated_values.right_arm_move == 0 || updated_values.right_arm_move==1 ){
                master_commands.right_arm_move = updated_values.right_arm_move;
                printf("right_arm_move value: %i\n",master_commands.right_arm_move);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for right_arm_move field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.right_arm_move);
            }
        }
        if( is_updated[EMOTION_STATUS]==1 ){
            if( updated_values.emotion_status<7 ){
                master_commands.emotion_status = updated_values.emotion_status;
                printf("emotion_status value: %i\n",master_commands.emotion_status);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for emotion_status field. Expected between 0 and 6. Received: %i\n\n", 
                updated_values.emotion_status);
            }
        }
        if( is_updated[LIGHT_STATUS]==1 ){
            if( updated_values.light_status > 6 && updated_values.light_status < 10 ){
                master_commands.light_status = updated_values.light_status;
                printf("light_status value: %i\n",master_commands.light_status);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for light_status field. Expected between 7 and 9. Received: %i\n\n", 
                updated_values.light_status);
            }
        }
        if( is_updated[PRINT_STATUS]==1 ){
            if( updated_values.print_status == 0 || updated_values.print_status==1 ){
                master_commands.print_status = updated_values.print_status;
                printf("print_status value: %i\n",master_commands.print_status);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for print_status field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.print_status);
            }
        }
        if( is_updated[FACE_COGNITION_STATUS]==1 ){
            if( updated_values.face_cognition_status == 0 || updated_values.face_cognition_status==1 ){
                master_commands.face_cognition_status = updated_values.face_cognition_status;
                printf("face_cognition_status value: %i\n",master_commands.face_cognition_status);
            }else{
                cout << "value not valid" << endl;
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for face_cognition_status field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.face_cognition_status);
            }
        }
        if( is_updated[CARD_READER_STATUS]==1 ){
            if( updated_values.card_reader_status == 0 || updated_values.card_reader_status==1 ){
                master_commands.card_reader_status = updated_values.card_reader_status;
                printf("card_reader_status value: %i\n",master_commands.card_reader_status);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for card_reader_status field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.card_reader_status);
            }
        }
        if( is_updated[FACE_COGNITION_OUTCOME]==1 ){
            if( strpbrk(updated_values.face_cognition_outcome,key)==NULL ){
                if( master_commands.face_cognition_outcome != NULL){
                    free(master_commands.face_cognition_outcome);
                    master_commands.face_cognition_outcome = new char[strlen(updated_values.face_cognition_outcome)+1];
                }else
                    master_commands.face_cognition_outcome = new char[strlen(updated_values.face_cognition_outcome)+1];
                    strcpy(master_commands.face_cognition_outcome, updated_values.face_cognition_outcome);
                    printf("face_cognition_outcome value: %s\n",master_commands.face_cognition_outcome);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in face_cognition_outcome field. Received: %s\nName can't contain %s.\n\n", 
                updated_values.face_cognition_outcome,key);
            }
        }
        if( is_updated[ID_CARD_NAME]==1 ){
            if( strpbrk(updated_values.id_card_name,key)==NULL ){
                if( master_commands.id_card_name != NULL){
                    free(master_commands.id_card_name);
                    master_commands.id_card_name = new char[strlen(updated_values.id_card_name)+1];
                }else
                    master_commands.id_card_name = new char[strlen(updated_values.id_card_name)+1];
                    strcpy(master_commands.id_card_name, updated_values.id_card_name);
                    printf("id_card_name value: %s\n",master_commands.id_card_name);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in id_card_name field. Received: %s\nName can't contain %s.\n", 
                updated_values.id_card_name,key);
            }
        }
        if( is_updated[VISITEE_NAME]==1 ){
            if( strpbrk(updated_values.visitee_name,key)==NULL ){
                if( master_commands.visitee_name != NULL){
                    free(master_commands.visitee_name);
                    master_commands.visitee_name = new char[strlen(updated_values.visitee_name)+1];
                }else
                    master_commands.visitee_name = new char[strlen(updated_values.visitee_name)+1];
                    strcpy(master_commands.visitee_name, updated_values.visitee_name);
                    printf("visitee_name value: %s\n",master_commands.visitee_name);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in visitee_name field. Received: %s\nName can't contain %s.\n", 
                updated_values.visitee_name,key);
            }
        }
        if( is_updated[APPOINTMENT_DATE]==1 ){
            if( strpbrk(updated_values.appointment_date,key2)==NULL ){
                if( master_commands.appointment_date != NULL){
                    free(master_commands.appointment_date);
                    master_commands.appointment_date = new char[strlen(updated_values.appointment_date)+1];
                }else
                    master_commands.appointment_date = new char[strlen(updated_values.appointment_date)+1];
                    strcpy(master_commands.appointment_date, updated_values.appointment_date);
                    printf("appointment_date value: %s\n",master_commands.appointment_date);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_date field. Received: %s\nName can't contain %s.\n", 
                updated_values.appointment_date,key2);
            }
        }
        if( is_updated[APPOINTMENT_TIME]==1 ){
            if( strpbrk(updated_values.appointment_time,key2)==NULL ){
                if( master_commands.appointment_time != NULL){
                    free(master_commands.appointment_time);
                    master_commands.appointment_time = new char[strlen(updated_values.appointment_time)+1];
                }else
                    master_commands.appointment_time = new char[strlen(updated_values.appointment_time)+1];
                    strcpy(master_commands.appointment_time, updated_values.appointment_time);
                    printf("appointment_time value: %s\n",master_commands.appointment_time);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_time field. Received: %s\nName can't contain %s.\n", 
                updated_values.appointment_time,key2);
            }
        }
        if( is_updated[APPOINTMENT_LOCATION]==1 ){
            if( strpbrk(updated_values.appointment_location,key2)==NULL ){
                if( master_commands.appointment_location != NULL){
                    free(master_commands.appointment_location);
                    master_commands.appointment_location = new char[strlen(updated_values.appointment_location)+1];
                }else
                    master_commands.appointment_location = new char[strlen(updated_values.appointment_location)+1];
                    strcpy(master_commands.appointment_location, updated_values.appointment_location);
                    printf("appointment_location value: %s\n",master_commands.appointment_location);
            }else{
                printf("\nWARNING: Field NOT updated. \nSpecial characters detected in appointment_location field. Received: %s\nName can't contain %s.\n", 
                updated_values.appointment_location,key2);
            }
        }
        if( is_updated[SPEECH_REQUEST]==1 ){
            if( updated_values.speech_request == 0 || updated_values.speech_request==1 ){
                master_commands.speech_request = updated_values.speech_request;
                printf("speech_request value: %i\n",master_commands.speech_request);
            }else{
                printf("\nWARNING: Field NOT updated. \nOut of range value dectected for speech_request field. Expected between 0 and 1. Received: %i\n\n", 
                updated_values.speech_request);
            }
        }
    }else{
        printf("\nWARNING: Requested update time stamped in the past. \nLast Master Update: %s, Time Stamp of Update: %s\n",
        master_commands.updated,updated_values.updated);
        }

    cout << "Update Completed\n" << endl;
    //exit(0);
}

int base_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"base_busy")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.is_base_busy=atoi(str_tok_buf_tmp[3].tok);
                is_updated[IS_BASE_BUSY] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"pos_x")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.base_position_x=atof(str_tok_buf_tmp[5].tok);
                is_updated[BASE_POSITION_X] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"pos_y")==0 ){
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 ){
                command_update.base_position_y=atof(str_tok_buf_tmp[7].tok);
                is_updated[BASE_POSITION_Y] = 1;
            }
        }
        /*if( strcmp(str_tok_buf_tmp[8].tok,"light_state")==0 ){
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 ){
                command_update.light_status=atoi(str_tok_buf_tmp[9].tok);
                is_updated[LIGHT_STATUS] = 1;
            }
        }*/
        if( strcmp(str_tok_buf_tmp[8].tok,"speech_request")==0 ){
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 ){
                command_update.speech_request=atoi(str_tok_buf_tmp[9].tok);
                is_updated[SPEECH_REQUEST] = 1;
            }
        }

        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int arms_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"left_busy")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.is_left_arm_busy=atoi(str_tok_buf_tmp[3].tok);
                is_updated[IS_LEFT_ARM_BUSY] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"right_busy")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.is_right_arm_busy=atoi(str_tok_buf_tmp[5].tok);
                is_updated[IS_RIGHT_ARM_BUSY] = 1;
            }
        }
        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int detect_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"emotion")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.emotion_status=atoi(str_tok_buf_tmp[3].tok);
                is_updated[EMOTION_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"cog_status")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.face_cognition_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[FACE_COGNITION_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"cog_outcome")==0 ){
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 ){
                command_update.face_cognition_outcome=str_tok_buf_tmp[7].tok;
                is_updated[FACE_COGNITION_OUTCOME] = 1;
            }
        }
        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int printer_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"print_status")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.print_status=atoi(str_tok_buf_tmp[3].tok);
                is_updated[PRINT_STATUS] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"card_status")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.card_reader_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[CARD_READER_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int face_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"forward_step")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.base_forward_step=atoi(str_tok_buf_tmp[3].tok);
                is_updated[BASE_FORWARD_STEP] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"backward_step")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.base_backward_step=atoi(str_tok_buf_tmp[5].tok);
                is_updated[BASE_BACKWARD_STEP] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[6].tok,"rotate_left")==0 ){
            if ( strcmp(str_tok_buf_tmp[7].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[7].tok,"(null)")!=0 ){
                command_update.base_rotate_left=atoi(str_tok_buf_tmp[7].tok);
                is_updated[BASE_ROTATE_LEFT] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[8].tok,"rotate_right")==0 ){
            if ( strcmp(str_tok_buf_tmp[9].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[9].tok,"(null)")!=0 ){
                command_update.base_rotate_right=atoi(str_tok_buf_tmp[9].tok);
                is_updated[BASE_ROTATE_RIGHT] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[10].tok,"light_status")==0 ){
            if ( strcmp(str_tok_buf_tmp[11].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[11].tok,"(null)")!=0 ){
                command_update.light_status=atoi(str_tok_buf_tmp[11].tok);
                is_updated[LIGHT_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int scanner_cmd_update(struct command_unit& command_update, str_tok_buffer& str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};

    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        // Reset command structure
        command_update = command_unit();
        
        if( strcmp(str_tok_buf_tmp[2].tok,"id_card_name")==0 ){
            if ( strcmp(str_tok_buf_tmp[3].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[3].tok,"(null)")!=0 ){
                command_update.id_card_name=str_tok_buf_tmp[3].tok;
                is_updated[ID_CARD_NAME] = 1;
            }
        }
        if( strcmp(str_tok_buf_tmp[4].tok,"card_status")==0 ){
            if ( strcmp(str_tok_buf_tmp[5].tok,"(NULL)")!=0 && strcmp(str_tok_buf_tmp[5].tok,"(null)")!=0 ){
                command_update.card_reader_status=atoi(str_tok_buf_tmp[5].tok);
                is_updated[CARD_READER_STATUS] = 1;
            }
        }
        time_stamp(command_update.updated);
    } 
    else {
        return -1;
    }

    update_master_commands( command_update, is_updated );

    return 1;
}

int lights_cmd_update(str_tok_buffer& str_tok_buf_tmp){
    if( strcmp(str_tok_buf_tmp[1].tok,"update")==0 ) {
        return 1;
    }
    return -1;
}

void print_command_struct(struct command_unit print_data, const char* str){
    printf("\n\n%s Conatins: \ncontrolid [%i], \nis_base_busy [%i], \nbase_position_x [%f], \nbase_position_y [%f],"
        "\nbase_destination_x [%f], \nbase_destination_y [%f], \nbase_forward_step [%i], \nbase_backward_step [%i], \nbase_rotate_left [%i]," 
        "\nbase_rotate_right [%i], \nis_left_arm_busy [%i], \nis_right_arm_busy [%i], \nleft_arm_move [%i], \nright_arm_move [%i], \nemotion_status [%i]," 
        "\nlight_status [%i], \nprint_status [%i], \nface_cognition_status [%i], \ncard_reader_status [%i], \ncreated [%s], \nupdated [%s],"
        "\nface_cognition_outcome [%s], \nid_card_name [%s], \nvisitee_name [%s], \nappointment_date [%s], \nappointment_time [%s], \nappointment_location [%s]\n",
        str,print_data.controlid,print_data.is_base_busy,print_data.base_position_x,print_data.base_position_y,print_data.base_destination_x,
        print_data.base_destination_y,print_data.base_forward_step,print_data.base_backward_step,print_data.base_rotate_left,print_data.base_rotate_right,
        print_data.is_left_arm_busy,print_data.is_right_arm_busy,print_data.left_arm_move,print_data.right_arm_move,print_data.emotion_status,
        print_data.light_status,print_data.print_status,print_data.face_cognition_status,print_data.card_reader_status,print_data.created,print_data.updated,
        print_data.face_cognition_outcome,print_data.id_card_name,print_data.visitee_name,print_data.appointment_date,print_data.appointment_time,print_data.appointment_location);
}

int send_master_commands_update(int newsockfd){
    char update_buffer[WRITE_BUFFER_LENGTH];

    //time_stamp(master_commands.updated);

    sprintf(update_buffer,"base_busy,%i,base_pos_x,%f,base_pos_y,%f,base_dest_x,%f,base_dest_y,%f,forward_step,%i,backward_step,%i,rotate_left,%i,rotate_right,%i,left_busy,%i,right_busy,%i,"
    "left_arm_move,%i,right_arm_move,%i,emotion_status,%i,light_status,%i,print_status,%i,face_cognition_status,%i,card_reader_status,%i,face_cognition_outcome,%s,id_card_name,%s,"
    "visitee_name,%s,appointment_date,%s,appointment_time,%s,appointment_location,%s,speech_request,%i,<EOC>",
    master_commands.is_base_busy,master_commands.base_position_x,master_commands.base_position_y,master_commands.base_destination_x,master_commands.base_destination_y,master_commands.base_forward_step,
    master_commands.base_backward_step,master_commands.base_rotate_left,master_commands.base_rotate_right,master_commands.is_left_arm_busy,master_commands.is_right_arm_busy,master_commands.left_arm_move,
    master_commands.right_arm_move,master_commands.emotion_status,master_commands.light_status,master_commands.print_status,master_commands.face_cognition_status,master_commands.card_reader_status,
    master_commands.face_cognition_outcome,master_commands.id_card_name,master_commands.visitee_name,master_commands.appointment_date,master_commands.appointment_time,master_commands.appointment_location,master_commands.speech_request);
 
    return tcp_write(newsockfd,update_buffer);
}

void update_mysql_cmd_unit(str_tok_buffer str_tok_buf_tmp){
    char is_updated[COMMAND_UNIT_LENGTH] = {};
    mysql_commands = command_unit();

    if( (str_tok_buf_tmp[BASE_DESTINATION_X].tok!="(NULL)") || (str_tok_buf_tmp[BASE_DESTINATION_X].tok!="(null)") ){
        mysql_commands.base_destination_x = atof(str_tok_buf_tmp[BASE_DESTINATION_X].tok);
        is_updated[BASE_DESTINATION_X] = 1;
    }

    if( (str_tok_buf_tmp[BASE_DESTINATION_Y].tok!="(NULL)") || (str_tok_buf_tmp[BASE_DESTINATION_Y].tok!="(null)") ){
        mysql_commands.base_destination_y = atof(str_tok_buf_tmp[BASE_DESTINATION_Y].tok);
        is_updated[BASE_DESTINATION_Y] = 1;
    }

    if( (str_tok_buf_tmp[UPDATED].tok!="(NULL)") || (str_tok_buf_tmp[UPDATED].tok!="(null)") ){
        strcpy(mysql_commands.updated, str_tok_buf_tmp[UPDATED].tok); 
        is_updated[UPDATED] = 1;
    }

    update_master_commands(mysql_commands, is_updated);

    /*    
    mysql_commands.controlid = atoi(str_tok_buf_tmp[0].tok); 
    mysql_commands.is_base_busy = atoi(str_tok_buf_tmp[1].tok);
    mysql_commands.base_position_x = atof(str_tok_buf_tmp[2].tok); 
    mysql_commands.base_position_y = atof(str_tok_buf_tmp[3].tok);
    if( (str_tok_buf_tmp.tok[BASE_DESTINATION_X]!="(NULL)") || (str_tok_buf_tmp.tok[BASE_DESTINATION_X]!="(null)") )
        mysql_commands.base_destination_x = atof(str_tok_buf_tmp[BASE_DESTINATION_X].tok);
    if( (str_tok_buf_tmp.tok[BASE_DESTINATION_Y]!="(NULL)") || (str_tok_buf_tmp.tok[BASE_DESTINATION_Y]!="(null)") )
        mysql_commands.base_destination_y = atof(str_tok_buf_tmp[BASE_DESTINATION_Y].tok);
    mysql_commands.base_forward_step = atoi(str_tok_buf_tmp[6].tok); 
    mysql_commands.base_backward_step = atoi(str_tok_buf_tmp[7].tok);
    mysql_commands.base_rotate_left = atoi(str_tok_buf_tmp[8].tok); 
    mysql_commands.base_rotate_right = atoi(str_tok_buf_tmp[9].tok);
    mysql_commands.is_left_arm_busy = atoi(str_tok_buf_tmp[10].tok); 
    mysql_commands.is_right_arm_busy = atoi(str_tok_buf_tmp[11].tok);
    mysql_commands.left_arm_move = atoi(str_tok_buf_tmp[12].tok); 
    mysql_commands.right_arm_move = atoi(str_tok_buf_tmp[13].tok);
    mysql_commands.emotion_status = atoi(str_tok_buf_tmp[14].tok); 
    mysql_commands.light_status = atoi(str_tok_buf_tmp[15].tok);
    mysql_commands.print_status = atoi(str_tok_buf_tmp[16].tok); 
    mysql_commands.face_cognition_status = atoi(str_tok_buf_tmp[17].tok);
    mysql_commands.card_reader_status = atoi(str_tok_buf_tmp[18].tok); 
    strcpy(mysql_commands.created, str_tok_buf_tmp[19].tok);
    if( (str_tok_buf_tmp.tok[UPDATED]!="(NULL)") || (str_tok_buf_tmp.tok[UPDATED]!="(null)") )
        strcpy(mysql_commands.updated, str_tok_buf_tmp[UPDATED].tok); 
    mysql_commands.face_cognition_outcome = str_tok_buf_tmp[21].tok;*/

}

int mysql_str_to_array(char* sql_data, str_tok_buffer str_tok_buf_tmp){
    char* pch;
    int j=1;

    if( sql_data == NULL ){
        printf("\nWARNING: cannot split array, sql_data empty.\n");
        return -1;
    }

    pch = strtok(sql_data,",");

    str_tok_buf_tmp[0].tok = pch;

    while(pch != NULL){
        pch = strtok(NULL,",");
        str_tok_buf_tmp[j].tok = pch;
        ++j;
    }

    for(int l=0;l<COMMAND_UNIT_LENGTH;++l){
        if( str_tok_buf_tmp[l].tok == NULL )
            break;
        else
        printf("str_tok_buf_tmp[%i]: %s\n",l,str_tok_buf_tmp[l].tok);
    }

    update_mysql_cmd_unit(str_tok_buf_tmp);
}

string read_from_mysql_db(){
    MYSQL *connection;
    MYSQL_RES *result;
    MYSQL_ROW row;
    MYSQL_FIELD *field;
    std::string s;

    connection = mysql_init(NULL);

    if (mysql_real_connect(connection, "107.180.100.50", "wizoApp", "321Wizo..","Wizo", 0, NULL, 0) == NULL){
     	fprintf(stderr, "%s\n", mysql_error(connection));
     	mysql_close(connection);
     	//exit(1);
        return "";
 	}
    
    if(mysql_query(connection, "SELECT * FROM Wizo.control_unit ORDER BY control_unit.controlid desc limit 1")){
        ROS_INFO("Query Error: %s", mysql_error(connection));
        //exit(1);
    }

    result = mysql_use_result(connection);

    for(int i=0; i < mysql_field_count(connection); ++i){
        std::stringstream ss;
        row = mysql_fetch_row(result);

        if(row <= 0)
            break;

        for(int j=0; j < mysql_num_fields(result); ++j){
                ss << row[j];
                if( j == mysql_num_fields(result)-1 ) s = s + row[j];
                else s = s + row[j] + ",";
            }
        //cout << "Row[] contains: " << s << endl;
        mysql_free_result(result);
        mysql_close(connection);
        
        return s;
    }
}

void update_mysql_db(){
    MYSQL *connection;
    MYSQL_RES *result;
    MYSQL_ROW row;
    MYSQL_FIELD *field;
    
    connection = mysql_init(NULL);

    if (mysql_real_connect(connection, "107.180.100.50", "wizoApp", "321Wizo..","Wizo", 0, NULL, 0) == NULL){
     	fprintf(stderr, "%s\n", mysql_error(connection));
     	mysql_close(connection);
        //return -1;
 	}

     char query_str[256]; 
     sprintf(query_str, "UPDATE Wizo.control_unit SET control_unit.is_base_busy=%i, control_unit.base_position_x=%f,"
     " control_unit.base_position_y=%f WHERE control_unit.controlid=1",master_commands.is_base_busy,master_commands.base_position_x,
     master_commands.base_position_y);
     
     printf("SQL Query formed:\n%s\n",query_str);

    if(mysql_query(connection, query_str)){
        fprintf(stderr,"Query Error: %s\n", mysql_error(connection));
        return;
    }
    mysql_close(connection);
}

void mysql_cmd_update(str_tok_buffer& str_tok_buf_tmp){

    string str = read_from_mysql_db();
    if( str.empty() )
        return;
    char* data_buffer = new char[str.size()+1];
    std::copy(str.begin(), str.end(), data_buffer);
    data_buffer[str.size()] = '\0';

    mysql_str_to_array(data_buffer, str_tok_buf_tmp);

    delete(data_buffer);
    str.clear();

    //print_command_struct(mysql_commands, "MYSQL_CMDS");
    //print_command_struct(master_commands,"MASTER_CMDS_2");
}


int main (int argc, char** argv)
{

    ros::init(argc, argv, "server_node");
    ros::NodeHandle nh;

    int sockfd, newsockfd, maxfd, portno; //Socket file descriptors and port number
    char* read_buffer;//[256]; // buffer array of size 256
    char write_buffer[256]; // buffer array of size 256 for sending messages
    int n, update_success=0;

    str_tok_buffer str_tok_buf = {NULL};
    str_tok_buffer sql_str_tok_buf = {NULL};

    ros::Duration d(0.001); // 1000Hz

    if (argc < 2) {
        fprintf(stderr,"ERROR, no port provided\n");
        exit(1);
    }

    //print_mysql_commands();

    portno = atoi(argv[1]);
    sockfd = create_tcp_socket(portno);
    listen(sockfd,10);
    newsockfd = listen_for_client(sockfd);

    if (-1 == (fcntl(sockfd, F_SETFD, O_NONBLOCK))){ 
        printf("ERROR Failed to set nonblock flag\n");
        exit(1);
    }

    //cout<<"sockfd: "<<sockfd<<endl;
    //cout<<"newsockfd: "<<newsockfd<<endl; 

    fd_set sockset, masterfd;
    FD_ZERO(&sockset);
    FD_ZERO(&masterfd);
    FD_SET(sockfd, &masterfd);
    FD_SET(newsockfd, &masterfd);

    maxfd = newsockfd;

    struct timeval tv, tv_timer; // timeout struct for socket calls

    set_timer(tv_timer,MYSQL_UPDATE_TIME);

    // TEMP DATA REMOVE BEFORE DEPLOY !!!!!!!!
    char vname[] = "Hamzah Al Ali";
    master_commands.visitee_name = new char[strlen(vname)+1];
    strcpy(master_commands.visitee_name,vname);
    char adate[] = "Jan 5 2017";
    master_commands.appointment_date = new char[strlen(adate)+1];
    strcpy(master_commands.appointment_date,adate);
    char atime[] = "14:30";
    master_commands.appointment_time = new char[strlen(atime)+1];
    strcpy(master_commands.appointment_time,atime);
    char location[] = "North Side Gate E75";
    master_commands.appointment_location = new char[strlen(location)+1];
    strcpy(master_commands.appointment_location,location);
    int temp_speech = 1;
    master_commands.speech_request = temp_speech;
    
  while(ros::ok()) {
    //cout << "just looping" << endl;
    memcpy(&sockset,&masterfd,sizeof(masterfd));

    int fail_count = 0;

    while( update_success < 1 ){
        if( fail_count > 2 ){
            close_tcp_socket(newsockfd,masterfd);
            break;
        }

        tv.tv_sec = 2;
        //tv.tv_usec = 100000;
        printf("Waiting for message from client on socket %i\n",newsockfd);
        int result = select(newsockfd + 1, &sockset, NULL, NULL, &tv);

        printf("Number of SOCK Fd's with read event ready: %i\n",result);

        //cout <<"newsockfd: "<<FD_ISSET(newsockfd, &sockset)<<endl;
        //cout<<"sockfd: "<<FD_ISSET(sockfd, &sockset)<<endl;

        if (result < 0) {
            printf("\nWARNING: No Read Event on Any Socket\n");
        }
        else if (FD_ISSET(newsockfd, &sockset)){//if (result == 1) {
            // The socket has data. For good measure, it's not a bad idea to test further
            printf("Read Event on Socket %i, I/O in progress...\n",newsockfd);

            read_buffer = new char[256];
            read_buffer = tcp_read(newsockfd);
            printf("\n\nMSG RECEIVED: \n\"%s\"\n\n",read_buffer);

            // Split received msg and update cmd structures.
            if(tcp_str_to_array(read_buffer,str_tok_buf)>0){
    
                if(strcmp(str_tok_buf[0].tok,"base")==0){
                    update_success = base_cmd_update(tcp_commands, str_tok_buf);
                    if( update_success > 0 ) 
                        update_mysql_db(); // updates base_pos_x/y and is_busy at the moment
                        /* Use these to debug what commands are received
                        print_command_struct(tcp_commands,"TCP_CMDS");
                        print_command_struct(master_commands,"MASTER_CMDS");
                    */
                }
                else if(strcmp(str_tok_buf[0].tok,"arms")==0){
                    update_success = arms_cmd_update(tcp_commands, str_tok_buf);
                }
                else if(strcmp(str_tok_buf[0].tok,"detect")==0){
                    update_success = detect_cmd_update(tcp_commands, str_tok_buf);
                }
                else if(strcmp(str_tok_buf[0].tok,"printer")==0){
                    update_success = printer_cmd_update(tcp_commands, str_tok_buf);
                }
                else if(strcmp(str_tok_buf[0].tok,"face")==0){
                    update_success = face_cmd_update(tcp_commands, str_tok_buf);
                 /*   char write_buffer[] = "FAIL";
                    tcp_write(newsockfd, write_buffer);
                    update_success = 0;*/
                }
                else if(strcmp(str_tok_buf[0].tok,"scanner")==0){
                    update_success = scanner_cmd_update(tcp_commands, str_tok_buf);
                    //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                }
                else if(strcmp(str_tok_buf[0].tok,"lights")==0){
                    update_success = lights_cmd_update(str_tok_buf);
                    //print_command_struct(master_commands,"MASTER_CMDS --> SCANNER TEST <-- ");
                }else{
                    update_success = -1;
                }
                if( update_success < 0 ){
                    char write_buffer[] = "WARN: MSG not recognised,<EOC>";
                    if ( tcp_write(newsockfd,write_buffer) < 0){
                        close_tcp_socket(newsockfd, masterfd);
                        break;
                    }
                    ++fail_count;
                    continue;
                }

                if( update_success>0 ){
                    // Confirm msg successfully received
                    //char write_buffer[] = "rcvd,<EOC>";
                    //tcp_write(newsockfd,write_buffer);

                    // Send Master Commands Update
                    send_master_commands_update(newsockfd);

                    // close socket and remove from FD set
                    close_tcp_socket(newsockfd,masterfd);
                    //close(newsockfd);
                    //FD_CLR(newsockfd,&masterfd);
                    maxfd = sockfd; 
                    free(read_buffer);
                    break;
                }
            }
            else{
                char write_buffer[] = "WARN: Message received not comma seperated";
                if( tcp_write(newsockfd,write_buffer) < 0 ){
                    close_tcp_socket(newsockfd, masterfd);
                    break;
                }
                ++fail_count;
                continue;
            }
            free(read_buffer);
        }

        {
            char write_buffer[] = "FAIL";
            if ( tcp_write(newsockfd,write_buffer) < 0){
                close_tcp_socket(newsockfd, masterfd);
                break;
            }
            ++fail_count;
        }
    }
    //else {
        printf("Waiting for connection..\n");
        newsockfd = listen_for_client(sockfd);
        FD_SET(newsockfd,&masterfd);
        printf("Connection accepted on socket %i\n",newsockfd);
        update_success = 0;
    //sleep(1);
    //}

    if( check_timer(tv_timer, MYSQL_UPDATE_TIME) == 1 ){
        printf("\n\nReceiving MySQL table update..\n\n");
        mysql_cmd_update(sql_str_tok_buf);
    }

  }
  return 0;
}